if (document.location.protocol == "http:" || document.location.protocol == "https:") {
    // If we are serving up in a webpage (like on our central page),
    // change the Atlas logo to link back to website root
    document.querySelectorAll("a.md-logo").forEach(function(node){
        if (node.title == "Atlas 2.0") {
            node.href="/";
        }
    });
} else {
    // If we're not on the web, the search box won't work because ajax calls are
    // now blocked by the browser. Remove it.
    var searchNode = document.querySelector('.md-search');
    searchNode.parentNode.removeChild(searchNode);
}
