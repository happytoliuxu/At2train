#!/bin/bash
#
# This will setup a writable /vault on Catalina
set -e

# Get sudo
echo "This script needs sudo permissions. Prompting if needed"
sudo true

# Check that we have a data volume
DATA_VOLUME="/System/Volumes/Data"
if [[ ! -d "$DATA_VOLUME" ]]; then
    echo "Could not find data volume"
    exit 1
fi

# Ensure we have a synthetic.conf file
SYNTHETIC_FILE="/etc/synthetic.conf"
sudo touch "$SYNTHETIC_FILE"

function add_folder()
{
    local folder_name=$1
    local target_folder="$DATA_VOLUME/${folder_name}"

    if [[ -d "/${folder_name}" ]]; then
        echo "/${folder_name} already exist, skip"
        return
    fi

    echo "Create folder(${folder_name}) on data volume if needed"
    if [[ ! -d "$target_folder" ]]; then
        sudo mkdir "$target_folder"
    fi

    # Check synthetic.conf doesn't have a conflicting file
    if [[ "$(cat "$SYNTHETIC_FILE" |grep "^${folder_name}" |wc -l |sed 's/^ *//')" != "0" ]]; then
        echo "$SYNTHETIC_FILE already has a config for ${folder_name} so this script won't override it"
        return
    fi

    # Append the line we care about
    printf "${folder_name}\t$target_folder\n" |sudo tee -a "$SYNTHETIC_FILE" > /dev/null
}

add_folder "vault"
add_folder "AppleInternal"

echo "Fixed $SYNTHETIC_FILE. Reboot machine then try installing Atlas again"
