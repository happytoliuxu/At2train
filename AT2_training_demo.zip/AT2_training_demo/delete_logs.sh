#!/bin/sh
echo "\n-----------delete atlas2 logs------------"
cd $(dirname $0)
folderPath=$(pwd)
#sourcePath="${folderPath}/Atlas2"
#echo "sourcePath:" $sourcePath
targetPath="${HOME}/Library/Logs/Atlas"
echo "targetPath:" $targetPath

rm -rf "${targetPath}"

echo "-->>finish task."
echo "\n------------------done-------------------"