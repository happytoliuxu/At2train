#!/bin/sh
echo "\n-----------load atlas2 project------------"
cd $(dirname $0)
folderPath=$(pwd)
sourcePath="${folderPath}/Atlas2"
echo "sourcePath:" $sourcePath
targetPath="${HOME}/Library/Atlas2"
echo "targetPath:" $targetPath

rm -rf "${targetPath}"
cp -rf "${sourcePath}" "${targetPath}"
atlassigner "${sourcePath}/Config/sign.plist" "${targetPath}"

echo "-->>finish task."
echo "\n---------------------done-----------------"