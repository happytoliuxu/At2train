# coding=utf-8

import os
import sys

load_sh = sys.path[0] + "/load_atlas2.sh"
reload_atlascore2 = sys.path[0] + "/reloadAtlasCore2.sh"
delete_logs = sys.path[0] + "/delete_logs.sh"
# print(load_sh)

os.system(load_sh)
os.system(reload_atlascore2)
os.system(delete_logs)
print("all load done.")