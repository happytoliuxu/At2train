function main()
    --detect Devices
    Detection.addDevice("uart://fake-uart-10")
    Detection.addDevice("uart://fake-uart-20")
    -- Detection.addDevice("uart://fake-uart-30")
    -- Detection.addDevice("uart://fake-uart-40")
    -- Detection.addDevice("uart://fake-uart-50")
    -- Detection.addDevice("uart://fake-uart-60")
    -- Detection.addDevice("uart://fake-uart-70")
    -- Detection.addDevice("uart://fake-uart-80")

    local routingDeviceCallback = function(url)
        local groups = Detection.groups()
        local groupName = groups[1]
        group_index = tonumber(groupName)
        slot_index = tonumber(string.sub(url, -2, - 2))
        slots = Detection.slots()
        print("device detection group:" .. tostring(group_index) .. ' slot:' .. slots[slot_index])
        return slots[slot_index], group_index
    end
    Detection.setDeviceRoutingCallback(routingDeviceCallback)

     -- detect Resources
    Detection.addResource("fake-resource-0-0")
    local routingResourceCallback = function(url)
        group_index = tonumber(string.sub(url, -3, -3)) + 1
        print('resource detection url: ' .. url .. ' group index:' .. tostring(group_index))
        return url, group_index
    end
    Detection.setExpectedResources({"fake-resource-0-0"})
    Detection.setResourceRoutingCallback(routingResourceCallback)
end
