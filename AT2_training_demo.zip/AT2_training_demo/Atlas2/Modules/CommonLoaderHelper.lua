local plist2lua = require("Matchbox/plist2lua")

local helper = {}

local configPath = string.gsub(Atlas.assetsPath, "Assets", "Config")
helper.__config = plist2lua.read(configPath .. "/common_loader_helper.plist")
local modulePath = string.gsub(Atlas.assetsPath, "Assets", "Modules/Tech")

function helper.getLoaderSkipFileList()
    local list = helper.__config.SkipFileList and helper.__config.SkipFileList or {}
    table.insert(list, "Common.lua")
    table.insert(list, ".DS_Store")
    for index = 1, #list do
        list[index] = modulePath .. "/" .. list[index]
    end
    return list
end

function helper.getLoaderOverrideFileList()
    local list = helper.__config.OverrideFileList and helper.__config.OverrideFileList or {}
    for index = 1, #list do
        list[index] = modulePath .. "/" .. list[index]
    end
    return list
end

function helper.getLoaderOptionalFileList()
    local list = helper.__config.OptionalFileList and helper.__config.OptionalFileList or {}
    for index = 1, #list do
        list[index] = modulePath .. "/" .. list[index]
    end
    return list
end

return helper
