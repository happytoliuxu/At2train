-- This is the Tech function script for uart logger commands.
-- a wrapper is needed to parse parameters from Matchbox Input, Commands, AdditionalParameters and feed to functions in this script

local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")
local record = require("Matchbox/record")

local logger = {}

-- open uart logger using object from CommLoggerPlugin
-- @param AdditionalParameters["path"]:string
-- @param timeout:number, optional, 
-- @param AdditionalParameters["delimiter"]:string, optional, 
-- @return true if succeed to open, false if any error or failure detected
function logger.openUARTLogger(params)
    Log.LogInfo("*****openUARTlogger*****")
    local loggerType = params.AdditionalParameters["logger"]
    if loggerType == "dutLogger_UART" then
        Log.LogInfo("open dutLoggerUART...")
        local loggerUart = Device.getPlugin("dutLoggerUART")
        loggerUart.setDelimiter('\n')
        local result, ex = xpcall(loggerUart.open, debug.traceback, 20)
        local loggerStatus = loggerUart.isOpened()
        Log.LogInfo("dutLoggerUART isOpened: ", loggerStatus)
        if loggerStatus ~= 1 then error('open serial port fail') end
    else   --dutLogger_KIS
        Log.LogInfo("open dutLoggerKIS...")
        local loggerKIS = Device.getPlugin("dutLoggerKIS")
        loggerKIS.setDelimiter('\n')
        local result, ex = xpcall(loggerKIS.open, debug.traceback, 20)
        local loggerStatus = loggerKIS.isOpened()
        Log.LogInfo("dutLoggerKIS isOpened: ", loggerStatus) 
        if loggerStatus ~= 1 then error('open serial port fail') end
    end
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return retResult
end

-- close uart logger using object from CommLoggerPlugin
-- @param AdditionalParameters["path"]:string
-- @param timeout:number, optional, 
-- @return true if succeed to open, false if any error or failure detected
function logger.closeUARTLogger(params)
    Log.LogInfo("*****closeUARTLogger*****")
    local loggerType = params.AdditionalParameters["logger"]
    if loggerType == "dutLogger_UART" then
        local loggerUart = Device.getPlugin("dutLoggerUART")
        local result, ex = xpcall(loggerUart.close, debug.traceback)
        -- OS SYNC
        local runShellCmd = Device.getPlugin('RunShellCommand')
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        local loggerStatus = loggerUart.isOpened()
        Log.LogInfo("dutLoggerUART isOpened: ", loggerStatus) 
        if loggerStatus ~= 0 then error('close serial port fail') end 
    else   --dutLogger_KIS
        local loggerKIS = Device.getPlugin("dutLoggerKIS")
        local result, ex = xpcall(loggerKIS.close, debug.traceback)
        -- OS SYNC
        local runShellCmd = Device.getPlugin('RunShellCommand')
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        local loggerStatus = loggerKIS.isOpened()
        Log.LogInfo("dutLoggerKIS isOpened: ", loggerStatus)
        if loggerStatus ~= 0 then error('close serial port fail') end 
    end
	record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return retResult
end

return logger