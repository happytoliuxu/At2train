-------------------------------------------------------------------
----***************************************************************
----DUT Communication Mux Functions
----Created at: 08/26/2020
----Author: Roy Yang/Bin Zhao
----***************************************************************
-------------------------------------------------------------------

local dut = {}

-- Open dut channel
-- @param params(table): table of csv line
-- @return: open result(true/false)
function dut.open(params)
    -- local channel_to_open = params.getInput()[params.thread or "main"]
    local channel_to_open = Device.getPlugin("dut")
    if channel_to_open then
        return channel_to_open.open()
    else
        error(channel_to_open .. "not exists")
    end
end

-- Close dut channel
-- @param params(table): table of csv line
-- @return: close result(true/false)
function dut.close(params)
    -- local channel_to_close = params.getInput()[params.thread or "main"]
    local channel_to_close = Device.getPlugin("dut")
    if channel_to_close then
        return channel_to_close.close()
    else
        error(channel_to_close .. "not exists")
    end
end

-- function dut.getCurrentDataChannel(params)
--     local thread = params.thread or 'main'
--     return params.getInput()[thread]
-- end

function dut.getCurrentDataChannel(params)
    local hangTimeout = params.AdditionalParameters["hangTimeout"]
    Log.LogInfo("hangTimeout: ", hangTimeout)
    if hangTimeout ~= nil then
        Log.LogInfo("Return dut and  channelBuilder")
        return Device.getPlugin("dut"), Device.getPlugin("channelBuilder")
    else
        Log.LogInfo("Return dut")
        return Device.getPlugin("dut")
    end
end


-- Init channels allocation for dimensions model
function dut.channelAllocation(params)
    local mapping = params.getInput()
    local channel_name = params.AdditionalParameters["channel"]
    local thread = params.AdditionalParameters["channel"]
    if type(mapping) == type({}) then
        mapping[thread] = Device.getPlugin(channel_name)
    else
        mapping = {}
        mapping[thread] = channel_name
    end
    return mapping
end

return dut
