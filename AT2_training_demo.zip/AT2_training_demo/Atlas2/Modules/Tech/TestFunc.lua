
local Log = require('Matchbox/logging')
local record = require("Matchbox/record")

local TestFunc = {}

function TestFunc.initUserInfo(params)
	Device.updateInfo({['UserInfo'] = ''})
	record.createBinaryRecord(true, params.Technology, params.TestName..params.testNameSuffix, params.AdditionalParameters["subsubtestname"], '')
end

function TestFunc.TestDelay(params)
	local delay = params.AdditionalParameters['delay']
	-- if params.TestName == 'Init' then error('test fail with SOF flag!') end
	os.execute('sleep ' .. delay)
	record.createBinaryRecord(true, params.Technology, params.TestName..params.testNameSuffix, params.AdditionalParameters["subsubtestname"], '')
end

function TestFunc.getScanSn(params)
	-- Retrieve Data from Scan in device level Action Lua script.
	local InteractiveView = Device.getPlugin("InteractiveView")
	--Retrieve saved data
	local viewConfig = {
           ["length"] = 6,
           ["input"] = {"SN"}
    }
	local dataReturn = InteractiveView.showView(Device.systemIndex, viewConfig)
	local mlbSn = dataReturn['SN']
	--local dataReturn = 'DLC12345678901234'
	-- e.g. "DLXAAAAAAAAAAAAAA"
	-- Set dataReturn(SN) as primaryIdentity for DataReporting.
	DataReporting.primaryIdentity(mlbSn)
	DataReporting.submitAttribute('serialnumber', mlbSn)
	record.createBinaryRecord(true, params.Technology, params.TestName..params.testNameSuffix, params.AdditionalParameters["subsubtestname"], '')
	return dataReturn
end

function  TestFunc.getScanConfig(params)
	-- -- Define config for Scan View.
	local viewConfig = {
	      ["length"] = 6,
	      ["input"] = {"Config"}
	}
	local InteractiveView = Device.getPlugin("InteractiveView")
	local dataReturn = InteractiveView.showView(Device.systemIndex, viewConfig)
	-- local dataReturn = {}
	-- dataReturn['Config'] = 'config-1'
	if dataReturn ~= nil then
	    -- Get back scanned "Config" value
	    local config = dataReturn["Config"]
	    Device.updateInfo({['UserInfo'] = config})
	    DataReporting.submitAttribute('config', config)
	end
	record.createBinaryRecord(true, params.Technology, params.TestName..params.testNameSuffix, params.AdditionalParameters["subsubtestname"], '')
end

return TestFunc