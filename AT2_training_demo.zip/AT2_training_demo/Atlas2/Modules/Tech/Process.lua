--Process.lua
local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")
local enterEnv = require('Tech/enterEnv')

local Process = {}

myOverrideTable ={}
myOverrideTable.getSN = function()
    -- Send command and get SN and return it back.
    -- get MLB serialnumber
    local dut = Device.getPlugin("dut")
    local mlbsn = dut.mlbSerialNumber(10) --"DLC103300FHQ27Q1N"
    Log.LogInfo('Process getSN:'.. mlbsn)
    return mlbsn
end

function Process.startControl(param)
    local dutPluginName = param.AdditionalParameters.dutPluginName
    if dutPluginName == nil then
        error('dutPluginName missing in AdditionalParameters')
    end
    local dut = Device.getPlugin(dutPluginName)
    if dut == nil then
        error('DUT plugin '..tostring(dutPluginName)..' not found.')
    end
    local category = param.AdditionalParameters.category
    Log.LogInfo('Starting process control')
    if category ~= nil and category ~= '' then
        ProcessControl.start(dut, category, myOverrideTable)
    else
        ProcessControl.start(dut, myOverrideTable)
    end
end

function Process.finishControl(param)
    -- do not finish CB if not started.
    local inProgress = ProcessControl.inProgress()
    -- 1: started; 0: not started or finished.
    if inProgress == 0 then
        Log.LogInfo('Process control finished or not started; skip finishCB.')
		return 
	end
    local dutPluginName = param.AdditionalParameters.dutPluginName
    if dutPluginName == nil then
       error('dutPluginName missing in AdditionalParameters')
    end
    local dut = Device.getPlugin(dutPluginName)
    if dut == nil then
        error('DUT plugin '..tostring(param.Input)..' not found.')
    end
    -- read Poison flag from Input
    local Poison = param.Input
    if Poison == 'TRUE' then
        Log.LogInfo('Poison requested; poisoning CB.')
        ProcessControl.poison(dut, myOverrideTable)
    end
    Log.LogInfo('Finishing process control')
    ProcessControl.finish(dut, myOverrideTable)
end

return Process