local constant = {}

constant.cellConfig = {"X2539S", "X2539B"}

constant.noHalleyConfig_plist = "/Volumes/HedgehogRepo/Live/default/NoHalley_List_BI.plist"

constant.VENDOR_CODE_FOLDER = {BP = "Tech/BP", CYG = "Tech/CYG"}

constant.DEFAULT_DETECT_TIME = 120

constant.dutCommPath = "KIS"

constant.COMM_MUX = {
    KIS = {
        name = "KIS",
        setup_params = {
            log = {
                PostLogFile = "/DutCommunication/Debug_KIS/post_uart_kis.log",
                PreLogFile = "/DutCommunication/Debug_KIS/pre_uart_kis.log",
                SMTLogFile = "/DutCommunication/uart_kis.log"
            },
            delimiter = "] :-) ",
            hangDetection = false,
            active = false
        },
        primary = true,
        extra_logger = "KISLogger"
    },
    UART = {
        name = "UART",
        setup_params = {
            active = false,
            log = {
                PostLogFile = "/DutCommunication/Debug_AP/post_uart_uart.log",
                PreLogFile = "/DutCommunication/Debug_AP/pre_uart_uart.log",
                SMTLogFile = "/DutCommunication/uart_uart.log"
            },
            delimiter = "] :-) ",
            hangDetection = false
        },
        primary = false,
        extra_logger = "APUARTLogger"
    }
}

constant.LOG_FILE_PATH = {
    usbfs_log = "/usbfs.log",
    restore_folder = "/restore",
    rxburn_source_log_folder = "/private/var/logs/Astro/rxburn",
    rxburn_dest_log_folder = "/LogCollector/rxburn"
}

constant.BI_KOS_LIST = {"sc run", "hammer -fmc", "ddr margin", "ddr vref"}

constant.LIVE_FILE_PATH = '/Volumes/HedgehogRepo/Live/default/PRDoc_Override_MLB.plist'

constant.KOS_LED_COLOR = "RED"

constant.ATTRIBUTE_FILE = {Attributes = {SOC = {"Lot ID", "ECID Fuse"}}}

constant.STATION_TYPE = {
    SMT_BURNIN = 'SMT-BURNIN',
    SIP_DFU = 'DFU',
    PROV = 'DEVELOPMENT-PROV',
    RXBURN = 'SMT-DEVELOPMENT19',
    SMT_BURNIN_REL = 'SMT-DEVELOPMENT31',
    SMT_BURNIN_RRT = 'SMT-DEVELOPMENT32'
}

constant.SN_FILE_TEMP = "/Users/gdlocal/SN_FILE_TEMP"

constant.DEBUGGING_LOG_DISABLED = true

return constant
