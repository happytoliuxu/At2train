-- This is the Tech function script for aggregation of DUT communication releted functions.
-- a wrapper is needed to parse parameters from Matchbox Input, Commands, AdditionalParameters and feed to functions in this script

local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")
local record = require("Matchbox/record")

local stationUtils = {}

-- This function gets value of STATION_TYPE, it should use interface from StationInfo Utility
-- @return:string, value of station type identifier
function stationUtils.getStationType(params)
    Log.LogInfo("*****getStationType*****")
    local stationInfo = Device.getPlugin("stationInfoPlugin")
    local stationType = stationInfo.station_type()
    Log.LogInfo("stationType: ", stationType)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return stationType
end

-- This function gets value of fixture type
-- @param fixturType:string, fixture type
-- @return:string, value of fixture type identifier
function stationUtils.getFixtureType(params)
    Log.LogInfo("*****getFixtureType*****")
    local fixtureType = params.AdditionalParameters["fixtureType"]
    Log.LogInfo("fixtureType: ", fixtureType)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return fixtureType
end

-- This function gets value of bundle name
-- @param bundlePath:string, bundle name
-- @return:string, value of bundle name identifier
function  stationUtils.getBundleName(params)
    Log.LogInfo("*****getBundleName*****")
    -- get bundle name form gh_station_info.json
    local StationInfo = Device.getPlugin("stationInfoPlugin")
    local station_overlay = StationInfo.station_overlay()
    local bundleName_ghinfo = ''
    local temp_array = comFunc.splitString(station_overlay,'_')
    if #temp_array > 3 then bundleName_ghinfo = temp_array[4] end
    Log.LogInfo('Bundle name from gh_station_info is : ' .. bundleName_ghinfo)
    -- get bundle name from /Users/gdlocal/RestorePackage
    local bundleName_rp = ''
    local runShellCommand = Device.getPlugin("RunShellCommand")
    local dirFiles = runShellCommand.run("ls /Users/gdlocal/RestorePackage").output
    local dirLists = comFunc.splitBySeveralDelimiter(dirFiles,'\n\r')
    for i, dirName in ipairs(dirLists) do
        if dirName ~= 'CurrentBundle' then
            local subDirs = runShellCommand.run('ls /Users/gdlocal/RestorePackage/' .. dirName).output
            if string.find(subDirs, 'Restore') ~= nil then
                bundleName_rp = comFunc.splitString(dirName, '_')[1]
                break
            end
        end
    end
    Log.LogInfo('Bundle name from restorepackage  is : '..bundleName_rp)
    -- test fail
    if bundleName_ghinfo ~= bundleName_rp then error(string.format('Bundle from OVL %s mismatch with Bundle from restorepackage %s',bundleName_ghinfo,bundleName_rp)) end
    -- test pass
    Log.LogInfo(string.format('Get Bundle name [%s] successful', bundleName_ghinfo))
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return bundleName_ghinfo
end

-- This function construct fixture-id value from board-id & tray-id
-- @param boardBoard:string, fixture base board id
-- @param trayBoard:string, fixture tray board id
-- @return:string, fixture id string
function stationUtils.getFixtureID(params)
    Log.LogInfo("*****getFixtureID*****")
    local boardBoardID = params.AdditionalParameters['baseBoard']
    local trayBoardID = params.AdditionalParameters['trayBoard']
    local fixtureID = boardBoardID.."  "..trayBoardID
    local headID = string.sub(Device.identifier, -1, -1)
    -- upload to insight
    DataReporting.fixtureID(fixtureID, headID)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)
    return fixtureID
end

-- This function scans serial devices mounted on system, and confirm if KIS DockChannel devices exists
-- @param slot:number, id of the slot which needs to check 
-- @param timeout:number, time to scans system
-- @return true if devices all showing up, false if devices have not shown up when timeout exceeds
function stationUtils.scanKISDHDevices(params)
    Log.LogInfo("*****scanKISDHDevices*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))
    local function _getKISLocationID(slot)
        local kisLocationID = ""
        local runShellCmd = Atlas.loadPlugin("RunShellCommand")
        local response = runShellCmd.run("/usr/sbin/system_profiler SPUSBDataType").output
        local allDev = comFunc.splitString(response,"Product ID:")
        for i, dev in ipairs(allDev) do
          if dev:match("Serial Number: UNIT"..slot) and dev:match("Location ID:") then
              local productIDStr = comFunc.splitString(dev,"Location ID:")[2]
              -- Log.LogInfo("productIDStr: ", productIDStr)
              local locationIDStr = string.sub(productIDStr,4,11)
              -- 14620000
              Log.LogInfo("locationIDStr: ", locationIDStr)
              local fourByte = tonumber(string.sub(locationIDStr, 4, 4))-1
              kisLocationID = string.sub(locationIDStr,1,3)..fourByte .."1000"
              Log.LogInfo("kisLocationID: ", kisLocationID)
              -- kislocationid = "14611000"
              break
          end
        end
        return kisLocationID
    end
    local function _updateKIS(kisLocationID, _checkAllKIS)
        local runShellCmd = Atlas.loadPlugin('RunShellCommand')
        local comFunc = require("Matchbox/CommonFunc")
        -- regex 'kis-xxx-ch-0','kis-xxx-ch-1','kis-xxx-ch-2','kis-xxx-ch-3'
        local cmd = 'ls /dev/cu.kis-'..kisLocationID..'-ch-*'
        local response = runShellCmd.run(cmd).output
        local regex = Device.getPlugin('regex')
        if _checkAllKIS == 'YES' then
            local array = regex.groups(response,'kis-'..kisLocationID..'-ch-([0-3]{1})', 1)
            Log.LogInfo('REGEX result: ' .. #array)
            if #array == 4 then return true else return false end
        else
            local array = regex.groups(response,'kis-'..kisLocationID..'-ch-([0]{1})', 1)
            Log.LogInfo('REGEX result: ' .. #array)
            if #array == 1 then return true else return false end
        end
    end
    local slot = Device.systemIndex + 1
    local kisLocationID = _getKISLocationID(slot)
    local checkAllKIS = params.AdditionalParameters['checkAllKIS']
    local failMsg = "not find KIS devices"
    local result = false
    local startTime = os.time()
    repeat
        if _updateKIS(kisLocationID, checkAllKIS) then
            result = true
            break
        end
        os.execute('sleep 1') -- delay 1s
    until(os.difftime(os.time(), startTime) > params.Timeout)
    -- test fail
    if not result then error('not find KIS devices') end
    -- test pass
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return result
end

-- This function parse wsku data and construct to value needed to be uploaded to insight 
-- @param WSKU:array, wsku data from syscfg print WSKU
-- @return string, WSKU data joint together by " "
function stationUtils.getUnitWSKU(params)
    Log.LogInfo("*****getUnitWSKU*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))
    if params.InputValues == nil then error('Input values is nil, please check!') end
    if #params.InputValues ~= 3 then error('Input values count not 3, please check') end
    local v1, v2, v3 = table.unpack(params.InputValues)
    local unitWSKU = v1 .. " " .. v2 .. " " ..v3
    Log.LogInfo('unitWSKU:' .. unitWSKU)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return unitWSKU
end

-- This function returns usb location id in string for device based on slot identifier
-- @return string, usb location id
function stationUtils.getDeviceUSBLocation(params)
    Log.LogInfo("*****getDeviceUSBLocation*****")
    local kisLocationID = ""
    local slot = Device.systemIndex + 1
    local runShellCmd = Device.getPlugin("RunShellCommand")
    local response = runShellCmd.run("/usr/sbin/system_profiler SPUSBDataType").output
    local allDev = comFunc.splitString(response,"Product ID:")

    for i, dev in ipairs(allDev) do
        if dev:match("Serial Number: UNIT"..slot) and dev:match("Location ID:") then
            local productIDStr = comFunc.splitString(dev,"Location ID:")[2]
            -- Log.LogInfo("productIDStr: ", productIDStr)
            local locationIDStr = string.sub(productIDStr,2,11)
            -- 0x14620000
            Log.LogInfo("locationIDStr: ", locationIDStr)
            local fourByte = tonumber(string.sub(locationIDStr, 6, 6))-1
            kisLocationID = "usb://"..string.sub(locationIDStr,1,5)..fourByte .."1100"
            Log.LogInfo("kisLocationID: ", kisLocationID)
            -- usblocationid = "usb://0x14611100"
            break
        end
    end
    if kisLocationID ~= "" then
        record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    else
        error('Get Device USB Location FAIL')
    end
    return kisLocationID
end

function stationUtils.getAttrFromSFC(params)
    Log.LogInfo("*****getAttrFromSFC*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))
    local sfc = Device.getPlugin("SFC")
    local mlbsn = params.Input
    local attrName = params.AdditionalParameters["attr_name"]
    local stationInfo = Device.getPlugin("stationInfoPlugin")
    local stationID = stationInfo.station_id()
    -- Log.LogInfo("attrName: ", attrName)
    local status, attrTable = xpcall(sfc.getAttributes, debug.traceback, mlbsn, stationID, {attrName})
    if not status or attrTable == nil or attrTable[attrName] == nil then error("Get attribute "..attrName.." failed from SFC.") end
    Log.LogInfo("attrTable: ", comFunc.dump(attrTable))
    local attrValue = attrTable[attrName]
    Log.LogInfo("attrValue: ", attrValue)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    if attrName == 'project_code' then -- 'X2011S' -> 'X2011'
        local project_code = string.sub(attrValue, 1, 5)
        Log.LogInfo('get project_code : ' .. project_code)
        return project_code
    end
    return attrValue
end

function stationUtils.setDUTCommPath(params)
    Log.LogInfo("*****setDUTCommPath*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))
    local dutPath = params.AdditionalParameters["dutPath"]
    Log.LogInfo("dutPath: ", uartPath)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return dutPath
end

-- This function sets value of Uart Comm Path
-- @param uartPath:string, Uart Comm Path
-- @return:string, value of Uart Comm Path
function stationUtils.setUartCommPath(params)
    Log.LogInfo("*****setUartCommPath*****")
    local uartPath = params.AdditionalParameters["uartPath"]
    Log.LogInfo("uartPath: ", uartPath)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return uartPath
end

return stationUtils