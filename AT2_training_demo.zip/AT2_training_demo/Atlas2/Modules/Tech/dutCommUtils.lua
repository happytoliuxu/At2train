-- This is the Tech function script for aggregation of DUT communication releted functions.
-- a wrapper is needed to parse parameters from Matchbox Input, Commands, AdditionalParameters and feed to functions in this script

local Log = require("Matchbox/logging")
local dut = require("Tech/DutCmd")
local json = require("Matchbox/json")
local dutCommChannelMux = require("Tech/DutCommMux")
local comFunc = require("Matchbox/CommonFunc")
local plist2LUA = require("Matchbox/plist2lua")
local enterEnv = require('Tech/enterEnv')
local parser = require('Tech/Parser')
local csvLoad = require('Matchbox/CSVLoad')
local record = require("Matchbox/record")

dutCommUtils = {}

-- This function add boot args to DUT boot env variable. It supports both handle EFIDiags or iboot env
-- @param bootArgs:string, boot args to add
-- @return true if succeed, fail if fails
function dutCommUtils.addBootArg(params)
    Log.LogInfo("****addBootArg params : ", comFunc.dump(params))
    local subsubtestname = params.AdditionalParameters["subsubtestname"]
    local paraTab = {}
    paraTab['Technology'] = params.Technology
    paraTab['TestName'] = params.TestName
    paraTab['Timeout'] = 10
    paraTab['Commands'] = 'nvram --get boot-args'
    paraTab['Output'] = 'boot_args'
    paraTab.AdditionalParameters = {}
    paraTab.AdditionalParameters['auto-record'] = false
    paraTab.AdditionalParameters['subsubtestname'] = subsubtestname .. '_get boot-args_1'
    local currentArgs = dut.sendAndParseCommand(paraTab)
    Log.LogInfo('current boot-args : '..currentArgs)
    local bootArgs = params.AdditionalParameters["bootArgs"]
    if string.find(currentArgs, bootArgs) ~= nil then
        Log.LogInfo('Boot-args has '..bootArgs)
    else
        paraTab['Commands'] = "nvram --add boot-args ".. bootArgs
        paraTab.AdditionalParameters['subsubtestname'] = subsubtestname .. '_nvram --add boot-args'
        dut.sendCmd(paraTab)
        paraTab['Commands'] = 'nvram --save' 
        paraTab.AdditionalParameters['subsubtestname'] = subsubtestname .. '_nvram --save'
        dut.sendCmd(paraTab)
        paraTab['Commands'] = 'nvram --get boot-args'
        paraTab.AdditionalParameters['subsubtestname'] = subsubtestname .. '_get boot-args_2'
        local afterAddArgs = dut.sendAndParseCommand(paraTab)
        Log.LogInfo('after add boot-args : ' .. afterAddArgs)
        -- test fail
        if string.find(afterAddArgs, bootArgs) == nil then error('add bootArgs fail') end
    end 
    -- test pass
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return true
end

-- This function remove specified boot args from DUT boot env variable. It supports both handle EFIDiags or iboot env
-- @param bootArgs:string, boot args to remove
-- @return true if succeed, fail if fails
function dutCommUtils.deleteBootArgs(params)
    -- nvram --remove boot-args smt
    return error("Not Implemented")
end

-- This function set DUT boot env variable. It supports both handle EFIDiags or iboot env
-- @param varName:string, env variable name
-- @param varValue:string, env varaible value
-- @return true if succeed, fail if fails
function dutCommUtils.setBootEnv(params)
    return error("Not Implemented")
end

-- This function copy files from DUT through usbfs
-- @param debug:bool, turn on/off debugging verbose, default is false
-- @param file_to_copy:string, file path in DUT to copy
-- @param path_to_save:string, local path to save files
-- @return true if succeed, fail if fails
function dutCommUtils.copyFilesByUsbfs(params)
    local usbfs = Device.getPlugin('USBFS')
    local copyFileList = params.AdditionalParameters['copyFileList']
    local hostLogPath = Device.userDirectory .. params.AdditionalParameters['path_to_save']
    local logCollectFolder = Device.userDirectory .. "/LogCollector/"
    efiplugin = Device.getPlugin('dut')
    -- {"-v", "usb", "0xff", "-v", "fs", "0xff", "-g", usbfsHostLog, "-t"}
    usbfs.setHostToolArgs({"-v", "usb","0xff","-v","fs","0xff", "-g", hostLogPath, "-t"})
    usbfs.setDefaultTimeout(600)
    Log.LogInfo('plugin:',efiplugin)
    Log.LogInfo('hostFolderPath:',logCollectFolder)
    Log.LogInfo('copyFileList:',comFunc.dump(copyFileList))
    usbfs.copyToHost(efiplugin, logCollectFolder, copyFileList)
    -- check copy result
    local testName = params.TestName
    checkCopyPDCAFile = logCollectFolder .. testName .. "/PDCA.plist"
    if not comFunc.fileExists(checkCopyPDCAFile) then
        error('copy files by usbfs failure')
    end
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return true
end

-- This function parses pdca result files and uploads data to insight
-- @param file_to_parse:string, file path to parse
-- @return true if succeed, fail if fails
function dutCommUtils.uploadTestResults(params)
    local retResult = false
    local failMsg = 'test result FAIL'
    local pdcaFile = Device.userDirectory .. params.AdditionalParameters['file_to_parse']
    if comFunc.fileExists(pdcaFile) then
        local plistData = plist2LUA.read(pdcaFile)
        if plistData == nil or #plistData == 0 then error('PDCA.plist file format error') end
        -- upload test data to insight
        local tests = plistData['0']['Tests']
        for _, item in pairs(tests) do
            local result = item['result']
            if result == 'PASS' then
                record.createBinaryRecord(true, params.Technology, item['testname'], item['subtestname'], '')
            else
                record.createBinaryRecord(false, params.Technology, item['testname'], item['subtestname'], item['failure_message'])
            end
        end
        -- check overall result
        Log.LogInfo("overall result:", plistData['0']['overallresult'])
        if plistData['0']['overallresult'] == 'PASS' then
            retResult = true
            failMsg = ''
        end
    else
        failMsg = 'PDCA.plist not exists'
        Log.LogInfo('PDCA.plist file not exists!')
    end
    if not retResult then error(failMsg) end
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return retResult
end

function dutCommUtils.setRTC(paraTab)
    -- use EFIPlugin.setRTC() with plugin.isOpened() == 1
    -- if plugin.close() by Matchbox functions, 
    -- execute 'sync' and 'slepp 2' actions befor plugin.open() to fix 'serial port busy' bug
    local dut = Device.getPlugin("dut")
    if dut.isOpened() ~= 1 then
        -- OS SYNC
        local runShellCmd = Device.getPlugin('RunShellCommand')
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        dut.open(60)
    end
    local result, rtc = xpcall(dut.setRTC, debug.traceback)
    if not result then error('setRTC fail') end
    record.createBinaryRecord( true, paraTab.Technology, paraTab.TestName, paraTab.AdditionalParameters.subsubtestname)
    return true
end

function dutCommUtils.changeDutDelimiter(params)
    local dut = Device.getPlugin("dut")
    local delimiter = params.AdditionalParameters["delimiter"]
    dut.setDelimiter(delimiter)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
end


function dutCommUtils.checkACLogIsEmpty(params)
    local checkACLogResp = params.Input
    local checkACLogIsEmptyResult = string.find(checkACLogResp,"AC Log is Empty")
    Log.LogInfo('check AC Log is Empty result: ', tostring(checkACLogIsEmptyResult))
    local checkACLogIsNotEmptyResult = string.find(checkACLogResp, "AC Log is Not Empty")
    Log.LogInfo('check AC is Not Empty result: ', tostring(checkACLogIsNotEmptyResult))
    -- test fail
    if checkACLogIsEmptyResult == nil or checkACLogIsNotEmptyResult ~= nil then
        error('AC Log is Not Empty')
        return false
    end
    -- test pass
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return true
end

function dutCommUtils.getSerialNumber(params)
    Log.LogInfo("*****getSerialNumber****")
    Log.LogInfo("params: ", comFunc.dump(params))
    local function _getStrFromHex(data)
        if #data == 2 then
            item_hex = tonumber(data,16)
            item_char = string.char(item_hex)
            return item_char
        elseif #data == 8 then
            str = ''
            for i=3,0,-1 do
                item = string.sub(data, i*2+1, i*2+2)
                item_hex = tonumber(item,16)
                item_char = string.char(item_hex)
                str = str .. item_char
            end
            return str
        else
            print('data len:'..#data..'not match')
            return ''
        end
    end
    local mlbsn = nil
    -- follow Atals1 bootToiBootAndDiags
    local uart = Device.getPlugin("dut")
    uart.setDelimiter(']')
    uart.open(60)
    Log.LogInfo("uart isOpened: ", uart.isOpened())
    local array_size = 0
    local temp_hex_array = {}
    xpcall(uart.read, debug.traceback, 10, '') -- read bootup logs out
    xpcall(uart.send, debug.traceback, '?', 10) -- send ? to clear uart
    local cmd = 'syscfg print MLB#'
    local respStr = uart.send(cmd, 30)
    Log.LogInfo("uart resp:"..respStr)
    local regex = Device.getPlugin('regex')
    local array = regex.groups(respStr,'0x([0-f]{2,8})', 1)
    Log.LogInfo("parse result: "..comFunc.dump(array))
    
    for _, item in pairs(array) do
        if item[1] == nil then
            break
        end
        Log.LogInfo('index:'..tostring(array_size)..' value:'..item[1])
        if array_size > 1 then
            table.insert(temp_hex_array, item[1])
        end
        array_size = array_size + 1
    end
    local sizeSN = array_size
    Log.LogInfo("sizeSN:"..tostring(sizeSN))
    if sizeSN == 7 then
        Log.LogInfo("Unit is in iBoot mode")
        -- translate SN
        local sn_str = ''
        for _, item in pairs(temp_hex_array) do
            local sn_part = _getStrFromHex(item)
            print('sn_part:' .. sn_part)
            sn_str = sn_str .. sn_part
        end
        Log.LogInfo('translateSN:'..sn_str)
        mlbsn = sn_str
        uart.close() -- Close UART to release for EFI Diags
        -- OS SYNC
        local runShellCmd = Device.getPlugin('RunShellCommand')
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        -- fix bug of startprocess getSN error, Enter Diags
        local paraTab = {}
        paraTab.AdditionalParameters = {}
        paraTab.Technology = 'StartProcess'
        paraTab.TestName = 'getSerialNumber'
        paraTab.AdditionalParameters['subsubtestname'] = 'enter Diags'
        paraTab.Timeout = 60
        paraTab.Commands = 'diags'
        local enterEnv = require('Tech/enterEnv')
        enterEnv.enterEnv(paraTab)
    else
        Log.LogInfo("Unit is in diags mode")
        uart.close() -- Close UART to release for EFI Diags
        -- OS SYNC
        local runShellCmd = Device.getPlugin('RunShellCommand')
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        -- get MLB serialnumber from diags
        local efiDut = Device.getPlugin('dut')
        efiDut.setDelimiter('] :-) ')
        efiDut.open(60)
        efiDut.syncCmdResp(30)
        xpcall(efiDut.send, debug.traceback, '?', 10)
        mlbsn = efiDut.mlbSerialNumber(params.Timeout)
        efiDut.close()
        runShellCmd.run('sync')
        runShellCmd.run('sync')
        os.execute('sleep 2') -- Debug delay
        Log.LogInfo('diags mlbsn:'..mlbsn)
    end
    if mlbsn == nil or mlbsn == '' then
        error('get serialnumber fail')
    else
        -- attribute record
        local paraTab = {}
        paraTab.AdditionalParameters = {}
        paraTab.AdditionalParameters['attributeKey'] = 'serialnumber'
        paraTab.Input = mlbsn
        local M = require('Matchbox/Matchbox')
        M.createAttribute(paraTab)
        -- binary record
        record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
        DataReporting.primaryIdentity(mlbsn)
    end
    return mlbsn
end

function dutCommUtils.closeDUTComm(params)
    Log.LogInfo("*****closeDUTComm****")
    Log.LogInfo("params: ", comFunc.dump(params))
    local efiDut = Device.getPlugin('dut')
    local retResult, ex = xpcall(efiDut.close, debug.traceback)
    -- OS SYNC
    local runShellCmd = Device.getPlugin('RunShellCommand')
    runShellCmd.run('sync')
    runShellCmd.run('sync')
    os.execute('sleep 2') -- Debug delay
    local dutStatus = efiDut.isOpened()
    if dutStatus ~= 0 then error('close dut comm fail') end
    Log.LogInfo('closeDUTComm status: '..dutStatus)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
end

function dutCommUtils.changeDutDelimiter(params)
    Log.LogInfo("*****changeDutDelimiter****")
    Log.LogInfo("params: ", comFunc.dump(params))
    local dutChannel = Device.getPlugin('dut')
    local newDelimiter = params.AdditionalParameters["delimiter"]
    dutChannel.setDelimiter(newDelimiter)
    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
    return true
end

function dutCommUtils.sendAndParseConsolidatedCommand(params)
    Log.LogInfo("*****sendAndParseConsolidatedCommand****")
    Log.LogInfo("params: ", comFunc.dump(params))
    -- 1.get command response
    local socstnResp = dut.sendCmd(params, 1)
    Log.LogInfo('socstnResp:'..socstnResp)
    local socstnRespList = comFunc.splitString(socstnResp, 'SEGPE>')
    -- 2.filter response test item record
    -- 2021-06-10 17:45:57.493 <post--read>[81933]: PASS pmgr mode 0x0002255 (CMD_TIME=00:00:00.000385)
    record_item_list = {}
    for _, item in pairs(socstnRespList) do
        temp_arr = comFunc.splitString(item, '\n')
        for _2, item2 in pairs(temp_arr) do
            if string.find(item2, 'xfer con') ~= nil then
                if string.find(item2, 'socstnd.cmd') == nil then
                    table.insert(record_item_list,item2)
                    break
                end
            else
                if string.find(item2,'CMD_TIME') ~= nil then
                    table.insert(record_item_list,item2)
                    break
                end
            end
            
        end
    end
    -- 3.parser rtos testplan csv
    local rtosCSV = Atlas.assetsPath .. '/Tech/rtos.csv'
    if not comFunc.fileExists(rtosCSV) then
        error("rtos CSV not exists")
    end
    local rtosCSV_dict = csvLoad.loadTech(rtosCSV)
    local rtos_test_table = rtosCSV_dict['RTOS']
    -- 4.match all test result
    local rtos_all_pass = true
    local rtos_pass_result = {} -- record all pass items result
    local rtos_fail_result = {} -- record all fail items result
    local line_index = 1
    for _, item in pairs(rtos_test_table) do
        if item['Disable'] ~= 'Y' then
            addParams = item['AdditionalParameters']
            addParams_dict = json.decode(addParams)
            local expectStr = addParams_dict['expect'] .. ' ' .. item['Commands']
            record_item_name = addParams_dict['subsubtestname']
            record_item_str = record_item_list[line_index]
            if string.find(record_item_str, expectStr, 1, true) == nil then
                rtos_all_pass = false
                record.createBinaryRecord(false, params.Technology, params.TestName, record_item_name, 'FAIL')
                Log.LogInfo('NOT PASS INDEX:'..line_index)
                Log.LogInfo('->resp:['..record_item_str..'] len:'..tostring(#record_item_str))
                Log.LogInfo(('->expect:['..expectStr..'] len:'..tostring(#expectStr)))
                table.insert(rtos_fail_result, record_item_name)
            else
                record.createBinaryRecord(true, params.Technology, params.TestName, record_item_name, '')
                table.insert(rtos_pass_result, record_item_name)
            end
        end
        line_index = line_index + 1
    end
    -- 5. record rtos all test result
    params.AdditionalParameters['subsubtestname'] = 'Check RTOS All Items Result'
    if rtos_all_pass then
        record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
        return 'FALSE' -- PoisonFlag
    else
        for _, item in ipairs(rtos_fail_result) do
            Log.LogInfo('->rtos not pass item:['..item..']')
        end
        error('rtos not all pass')
        return 'TRUE'
    end
end

return dutCommUtils