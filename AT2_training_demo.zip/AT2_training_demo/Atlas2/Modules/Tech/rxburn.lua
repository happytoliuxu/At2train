-- This is the Tech function script for uart logger commands.
-- a wrapper is needed to parse parameters from Matchbox Input, Commands, AdditionalParameters and feed to functions in this script

local Log = require("Matchbox/logging")
local record = require("Matchbox/record")
local dutCmd = require("Tech/DUTCmd")
local commFunc = require("Matchbox/CommonFunc")

local rxburn = {}

-- clean up OSDTester state
-- @return true if succeed, false if fails
function rxburn.cleanupOSDTestState(params)
    return error("Not Implemented")
end

-- run a task on DUT through fdc, wait for finish & collect result
-- @param Commands:string
-- return output:dictionary, fdc remote task output
function rxburn.fdcRemoteTask(params)
    return error("Not Implemented")
end

-- run OSDNANDTest and collect test results
-- @param config:string
-- @return true if succeeds, false if fails 
function rxburn.runOSDNANDTest(params)
    return error("Not Implemented")
end


function rxburn.needRunNoHalley(params)
	Log.LogInfo("*****needRunNoHalley*****")
    if params.InputValues == nil then error('Input values is nil, please check!') end
    if #params.InputValues ~= 2 then error('Input values count not 2, please check') end
    local project_code, build_config = table.unpack(params.InputValues)
    local noHalleyProject = params.AdditionalParameters["noHalleyProject"]
    Log.LogInfo("noHalleyProject: ", noHalleyProject)
    local function _checkAndUpdateBB()
        -- Baseband on
        local paraTab = {}
        paraTab.Output = ''
        paraTab['Technology'] = 'Burnin'
        paraTab['TestName'] = 'Molotov'
        paraTab.AdditionalParameters = {}
        paraTab.Timeout = 30
        paraTab.AdditionalParameters['subsubtestname'] = 'Baseband on'
        paraTab.AdditionalParameters['auto-record'] = true
        paraTab.Commands = 'baseband --on'
        dutCmd.sendAndParseCommand(paraTab)
        -- Baseband load
        paraTab.AdditionalParameters['subsubtestname'] = 'Baseband load'
        paraTab.Commands = 'baseband --load_firmware'
        dutCmd.sendAndParseCommand(paraTab)
        -- baseband -p
        paraTab.Output = 'BBFWVER,BBSNUM'
        paraTab.AdditionalParameters['subsubtestname'] = 'Baseband -p'
        paraTab.Commands = 'baseband -p'
        local BBFWVER, BBSNUM = dutCmd.sendAndParseCommand(paraTab)
        Log.LogInfo("Unit BBFWVER : " .. BBFWVER)
        DataReporting.submit(DataReporting.createAttribute('BB_FIRMWARE_VERSION', BBFWVER))
        Log.LogInfo("Unit BBSNUM : " .. BBSNUM)
        DataReporting.submit(DataReporting.createAttribute('BB_SNUM', BBSNUM))
        -- Baseband off
        paraTab.Output = ''
        paraTab.AdditionalParameters['subsubtestname'] = 'Baseband off'
        paraTab.Commands = 'baseband --off'
        dutCmd.sendCmd(paraTab)
    end
    -- follow Atlas1
    local needRunNoHalleyFlag = "NO"
    if string.find(project_code, noHalleyProject) ~= nil then
        _checkAndUpdateBB()
        Log.LogInfo('Unit cfg : ' .. build_config)
        local StationInfo = Atlas.loadPlugin("StationInfo")
        local build_stage = StationInfo.build_stage()
        Log.LogInfo("build stage : "..build_stage)
        if build_stage ~= 'MP' then
            local noVinylList = {}
            local plist2LUA = require("Matchbox/plist2lua")
            local noHalleyListFile = '/Volumes/HedgehogRepo/Live/default/NoHalley_List_BI.plist'
            if not commFunc.fileExists(noHalleyListFile) then
                -- test fail
                error('load NoHalley plist failed, please check /Volumes/HedgehogRepo/Live/default/NoHalley_List_BI.plist if exist or wrong format')
            end
            local plistData = plist2LUA.read(noHalleyListFile)
            noVinylList = plistData["NoHalley"]
            Log.LogInfo('NoVinylList is : ' .. commFunc.dump(noVinylList))
            for _, item in pairs(noVinylList) do
                if item == build_config then
                    Log.LogInfo(string.format('found noVinyl unit cfg [%s] match', build_config))
                    needRunNoHalleyFlag = "YES"
                    break
                end
            end
        end
    else
        needRunNoHalleyFlag = "YES"
    end

    record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)
    return needRunNoHalleyFlag
end
    

return rxburn