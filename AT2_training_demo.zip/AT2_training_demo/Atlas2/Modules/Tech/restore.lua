-------------------------------------------------------------------
----***************************************************************
----restore functions
----***************************************************************
-------------------------------------------------------------------

local restore = {}

local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")
-- local ghStationInfo = require("ghStationInfo")
local record = require("Matchbox/record")

local DEFAULT_PR_FILE_PATH = "/Users/gdlocal/Library/Application Support/PurpleRestore/"
local DEVICE_WORKING_DIR = Device.userDirectory
local HOSTS_FILE = "/etc/hosts"
local FDRUCA_DOMAIN = "fdruca.apple.com"
local FDRDS_DOMAIN = "fdrds.apple.com"
local FDRUSS_DOMAIN = "fdruss.apple.com"
local FDRTRUST_URL = "http://fdruca.apple.com:8080/fdrtrustobject"


-- collect baseband updater coredump log after restore failed to replace manually collection
-- e.g. restore.collectBBUpdaterCoredump()
-- function restore.collectBBUpdaterCoredump(params)
--     -- expected features:
--     -- 1. extract baseband updater coredump log path based on special string: "Wrote baseband updater output to /tmp/baseband_updater_output-"
--     -- e.g. full path: /tmp/baseband_updater_output-1685CCC1-D212-401B-A72B-3D89A34EC3B3/
--     -- 2. copy coredump file to destination
--     local collectBBUpdaterCoredump__inner = function()
--         local restoreLogDir = Device.userDirectory
--     local filesStr = comFunc.runShellCmd("ls " .. restoreLogDir .. " 2>&1").output
--     local resotreHostPattern = "(restore_host_.-%.log)"
--     local _, _, resotreHostFile = string.find(filesStr, resotreHostPattern)
--     if resotreHostFile ~= nil then
--         local restoreHostLogPath = restoreLogDir .. "/" .. resotreHostFile
--         Log.LogInfo("restore.collectBBUpdaterCoredump -> restore host log path: " .. restoreHostLogPath)
--         if comFunc.fileExists(restoreHostLogPath) == true then
--             local restoreHostFileContent = comFunc.fileRead(restoreHostLogPath)
--             local pattern = "Wrote baseband updater output to (/tmp/baseband_updater_output-[%w%-]+)/"
--             local _, _, baseBandCoredumpPath = string.find(restoreHostFileContent, pattern)
--             if baseBandCoredumpPath ~= nil then
--                 Log.LogInfo("restore.collectBBUpdaterCoredump -> Basebandupdater coredump path is " .. baseBandCoredumpPath)
--                 local resultStr = comFunc.runShellCmd("cp -rf " .. baseBandCoredumpPath .. " " .. DEVICE_WORKING_DIR .. " 2>&1").output
--                 Log.LogInfo("restore.collectBBUpdaterCoredump -> ", resultStr)
--             else
--                 Log.LogInfo("restore.collectBBUpdaterCoredump -> Not found baseband updater coredump path")
--             end
--         else
--             Log.LogInfo("restore.collectBBUpdaterCoredump -> restore host file not exists")
--         end
--     else
--         Log.LogInfo("restore.collectBBUpdaterCoredump -> Not found restore host file")
--     end
--     end
--     local status, ret = xpcall(collectBBUpdaterCoredump__inner, debug.traceback)
--     local failMsg = nil
--     if not status then
--         failMsg = ret
--     end
--     record.createBinaryRecord(status, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)
--
-- end

-- check hosts file health and FDR server connection status after restore failed
-- @return boolean, if hosts file health and connection status OK return true else return false
-- e.g. result = restore.checkHostsHealthAndFDRConnection();
function restore.checkHostsHealthAndFDRConnection(params)
    -- expected features:
    -- 1. extract FDR server FDR server IP, if hosts file contain them it's heath or return false
    -- 2. Check FDR server connection status, if return ping succeeded mean status OK and return true or return false
    local checkHostsHealthAndFDRConnection__inner = function()
    local fdruca = ghStationInfo.FDRUCA_IP .. "%s+" .. FDRUCA_DOMAIN
    local fdrds = ghStationInfo.FDRDS_IP .. "%s+" .. FDRDS_DOMAIN
    local fdruss = ghStationInfo.FDRUSS_IP .. "%s+" .. FDRUSS_DOMAIN

    local hostsFileContent = comFunc.fileRead(HOSTS_FILE)
    if string.find(hostsFileContent, fdruca) and string.find(hostsFileContent, fdrds) and string.find(hostsFileContent, fdruss) then
        Log.LogInfo("restore.checkHostsHealthAndFDRConnection -> hosts file is ok")
    else
        Log.LogInfo("restore.checkHostsHealthAndFDRConnection -> /etc/hosts is not complete")
        return false
    end

    local runShell = Device.getPlugin("RunShellCommand")
    local cmdTable = {
                "nc -z " .. FDRDS_DOMAIN .. " 8443",
                "nc -z " .. FDRUCA_DOMAIN .. " 8443",
                "nc -z " .. FDRUCA_DOMAIN .. " 8080",
                "curl " .. FDRTRUST_URL .. "|echo"
            }
    local cmdExecResult = ""
    for _, cmd in ipairs(cmdTable) do
        local resultStr = runShell.run(cmd).error
        cmdExecResult = cmdExecResult == "" and resultStr or cmdExecResult .. " " .. resultStr
    end
    Log.LogInfo("cmdExecResult: ", cmdExecResult)

    if string.find(cmdExecResult, FDRDS_DOMAIN .. " port 8443 %[tcp/pcsync%-https%] succeeded") and
       string.find(cmdExecResult, FDRUCA_DOMAIN .. " port 8443 %[tcp/pcsync%-https%] succeeded") and
       string.find(cmdExecResult, FDRUCA_DOMAIN .. " port 8080 %[tcp/http%-alt%] succeeded") and
       #cmdExecResult > 100 then
        Log.LogInfo("restore.checkHostsHealthAndFDRConnection -> FDR server connection status is OK")
        return true
    else
        Log.LogInfo("restore.checkHostsHealthAndFDRConnection -> FDR server connection status is not OK")
        return false
    end
    end
    local status, ret = xpcall(checkHostsHealthAndFDRConnection__inner, debug.traceback)
    local failMsg = nil
    if not status then
        failMsg = "Host file not complete or FDR server connection is not OK"
    end
    record.createBinaryRecord(status, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)

end

-- check if restore panic
-- @param restoreUartLogPath string, the restore uart log path
-- @return boolean, if restore panic return true else return false
-- e.g. result = restore.isRestorePanic(params)
function restore.isRestorePanic(params)
    -- expected features:
    -- 1. check panic string in restore uart log, if contain, return true else return false
    -- e.g. panic str: "Debugger message: panic" or "Please go to https://panic.apple.com to report this panic"
    local isRestorePanic__inner = function()
        local restoreUartLogPath = ""
        if params.Input == "KIS" then
            restoreUartLogPath = Device.userDirectory .. "/UARTLogger-KIS/KIS_RestoreOnly.log"
        elseif params.Input == "APUART" then
            restoreUartLogPath = Device.userDirectory .. "/UARTLogger-APUart/APUART_All.log"
        end
        Log.LogInfo("Restore uart log path: ", restoreUartLogPath)
    if comFunc.fileExists(restoreUartLogPath) then
        local restoreUartFileContent = comFunc.fileRead(restoreUartLogPath)
        if string.find(restoreUartFileContent, "Debugger message: panic") or string.find(restoreUartFileContent, "Please go to https://panic.apple.com to report this panic") then
            Log.LogInfo("restore.isRestorePanic -> restore panic")
            return "TRUE"
        end
    end
    Log.LogInfo("restore.isRestorePanic -> restore not panic")
        return "FALSE"
    end
    local status, ret = xpcall(isRestorePanic__inner, debug.traceback)
    local failMsg = nil
    if status and ret == "TRUE" then
        failMsg = "Restore panic"
        status = false
    else
        status = true
    end
    record.createBinaryRecord(status, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)
    return ret
end

function restore.restore(params)
    local timeout = params.Timeout
    if timeout ~= nil then
        timeout = tonumber(timeout)
    else
        error("No timeout setting be found for restore, please check your TP")
    end
    local startTime = os.time()
    local dcsd_plugin = Device.getPlugin('dcsd_plugin')
    local workspace = Device.userDirectory
    local target = params.AdditionalParameters["target"]
    Log.LogInfo('======device_usb_url:' .. target)
    local dcsd_dut = dcsd_plugin.get_dcsd_dut_plugin(target, workspace)
    local pr_doc_path = DEFAULT_PR_FILE_PATH .. params.AdditionalParameters["pr"]
    local unit_start_time_string = tostring(os.date("%Y-%m-%d_%H-%M-%S"))
    local progress = dcsd_plugin.get_progress_plugin()
    dcsd_dut.restore_device(
                        pr_doc_path,                  -- PR_DOC_PATH
                        unit_start_time_string,       -- start date in yyyy-MM-dd_HH-mm-ss"
                        "sw_name",                      -- SWName
                        "sw_version",                   -- SWVersion
                        false,                    -- Whether to write SFC record
                        false,               -- Whether to use MPNRC from SFC
                        progress   -- For progress update
                        )
    repeat
        local msg = progress.getMessage()
        if msg ~= nil
        then
            Device.updateProgress(msg)
            Log.LogInfo(msg)
        end
    until(not progress.isRunning() or os.difftime(os.time(), startTime) >= timeout)
    if progress.isRunning() then
        error("Restore timeout error")
    end
    local command_result = progress.getResultAndError()
    local err_msg = command_result[progress.ERROR_MSG]
    if err_msg then
        error("restore failed with error " .. err_msg)
    end
end

return restore
