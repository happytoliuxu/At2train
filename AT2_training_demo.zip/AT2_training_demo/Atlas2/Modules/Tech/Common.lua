-- This scripts loads functions from scripts under Modules/Tech folder
local Log = require("Matchbox/logging")
local helper = {}

local SKIP_FILE_LIST = {"Common.lua"}

local techPath = string.gsub(Atlas.assetsPath, "Assets", "Modules/Tech")
local runShellCommand = Atlas.loadPlugin('RunShellCommand')
local comFunc = require("Matchbox/CommonFunc")
local techFiles = runShellCommand.run("ls ".. techPath).output
Log.LogDebug("file list: ", techFiles)
local techFileList = comFunc.splitBySeveralDelimiter(techFiles,'\n\r')
for i, file in ipairs(techFileList) do
    if not comFunc.hasVal(SKIP_FILE_LIST, file) then
        Log.LogInfo("file: ", file)
        local requirePath = "Tech/"..file:match("(.*)%.lua")
        local lib = require(requirePath)
        for name, func in pairs(lib) do
            helper[name] = function (params)
                params.Commands = params.varSubCmd()
                params.AdditionalParameters = params.varSubAP()
                return func(params)
            end
        end
    end
end

return helper