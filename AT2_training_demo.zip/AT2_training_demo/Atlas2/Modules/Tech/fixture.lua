-- This is the Tech function script for fixture commands. Script assumes the fixture plugin instance name is "fixture"
-- a wrapper is needed to parse parameters from Matchbox Input, Commands, AdditionalParameters and feed to functions in this script

local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")
local record = require("Matchbox/record")

local fixture = {}
fixture._plugin = Device and Device.getPlugin("BPfixture")

local CONN_ON = "ON"
local CONN_OFF = "OFF"

function fixture.record(params, result, failMsg)
    Log.LogInfo("*****fixture.record*****")
    record.createBinaryRecord(result, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], failMsg)
end


function fixture.fixtureOpen(params)
    Log.LogInfo("*****fixtureOpen*****")
    
    local slot = Device.systemIndex + 1
    local response = fixture._plugin.open(tostring(slot))

    local result = true
    local failMsg = ""
    if string.match(response, "Error") then
        result = false
        failMsg = response
        error('fixture open error')
    end
    fixture.record(params, result, failMsg)
    return response
end

function fixture.fixtureClose(params)
    Log.LogInfo("*****fixtureClose*****")

    local response = fixture._plugin.close()

    local result = true
    local failMsg = ""
    if string.match(response, "Error") then
        result = false
        failMsg = response
        error('fixture close error')
    end
    fixture.record(params, result, failMsg)
    return response
end

-- @params params: from test item
-- @params measurement: string, measure value
function fixture.parameteticRecord(params, measurement)
    Log.LogInfo("*****fixture.parameteticRecord*****")
    Log.LogInfo("params: ", comFunc.dump(params))
    local subsubtestname = params.AdditionalParameters["subsubtestname"]
    if params.limit ~= nil then
        local limit = params.limit[subsubtestname]
        record.createRecord(measurement, params.Technology, params.TestName, subsubtestname, limit, nil)
    else
        record.createRecord(measurement, params.Technology, params.TestName, subsubtestname, nil, nil)
    end
end

function fixture.reset(params)
    Log.LogInfo("*****reset*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.reset()
    local response = fixture._plugin.runCommand("reset",params)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.supply(params)
    Log.LogInfo("*****supply*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- local net = params.AdditionalParameters["net"]
    -- local connect = params.AdditionalParameters["connect"]
    -- local voltage = params.AdditionalParameters["voltage"]
    -- if connect ~= CONN_ON and connect ~= CONN_OFF then
    --     error("value of connect parameter can only be ON or OFF")
    -- end

    -- if connect == CONN_ON and type(voltage) ~= type(1) then
    --     error("connect to ON requires voltage to be a valid number")
    -- end

    -- return fixture._plugin.supply(net, connect, voltage)


    local paramsDic = {}
    paramsDic["net"] = params.AdditionalParameters["net"]
    paramsDic["connect"] = params.AdditionalParameters["connect"]
    paramsDic["voltage"] = params.AdditionalParameters["voltage"]
    local response = fixture._plugin.runCommand("supply",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end
    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.led(params)
    Log.LogInfo("*****led*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.led(color, status)

    local paramsDic = {}
    paramsDic["color"] = params.AdditionalParameters["color"]
    paramsDic["status"] = params.AdditionalParameters["status"]
    local response = fixture._plugin.runCommand("led",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.relay(params)
    Log.LogInfo("*****relay*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.relay(net, source)

    local paramsDic = {}
    paramsDic["net"] = params.AdditionalParameters["net"]
    paramsDic["source"] = params.AdditionalParameters["source"]
    local response = fixture._plugin.runCommand("relay",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.i2c_read(params)
    Log.LogInfo("*****i2c_read*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.i2c_read(device, reg, length, format)

    local paramsDic = {}
    paramsDic["device"] = params.AdditionalParameters["device"]
    paramsDic["reg"] = params.AdditionalParameters["reg"]
    paramsDic["length"] = params.AdditionalParameters["length"]
    paramsDic["format"] = params.AdditionalParameters["format"]
    local response = fixture._plugin.runCommand("i2c_read",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end
    
    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.i2c_write(params)
    Log.LogInfo("*****i2c_write*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.i2c_write(device, reg, data, format)

    local paramsDic = {}
    paramsDic["device"] = params.AdditionalParameters["device"]
    paramsDic["reg"] = params.AdditionalParameters["reg"]
    paramsDic["data"] = params.AdditionalParameters["data"]
    local response = fixture._plugin.runCommand("i2c_write",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.board_id(params)
    Log.LogInfo("*****board_id*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.board_id(device)

    local paramsDic = {}
    paramsDic["device"] = params.AdditionalParameters["device"]
    local response = fixture._plugin.runCommand("board_id",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.dmm(params)
    Log.LogInfo("*****dmm*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.dmm(net)

    local paramsDic = {}
    paramsDic["net"] = params.AdditionalParameters["net"]
    paramsDic["unit"] = params.AdditionalParameters["unit"]
    local response = fixture._plugin.runCommand("dmm",paramsDic)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end
    fixture.parameteticRecord(params, response)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.fw_ver(params)
    Log.LogInfo("*****fw_ver*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    -- return fixture._plugin.fw_ver()
    local response = fixture._plugin.runCommand("fw_ver",params)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.hw_ver(params)    
    Log.LogInfo("*****hw_ver*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))
    local response = fixture._plugin.runCommand("hw_ver",params)

    local result = true
    local failMsg = ""
    if string.match(response, "FAIL") then
        result = false
        failMsg = response
    end

    fixture.record(params, result, failMsg)
    if result == false then
        return error(response)
    end

    return response
end

function fixture.delay(params)
    Log.LogInfo("*****delay*****")
    -- Log.LogInfo("params: ", comFunc.dump(params))

    delaytime = params.AdditionalParameters["ms"]
    os.execute("sleep " .. tonumber(delaytime)/1000)

    local result = true
    local failMsg = ""
    if result == false then
        return error(response)
    end

    return result
end

return fixture