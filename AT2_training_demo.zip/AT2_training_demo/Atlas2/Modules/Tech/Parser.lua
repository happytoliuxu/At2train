-------------------------------------------------------------------
----***************************************************************
----Parser Functions
----Created at: 07/21/2020
----Author: Bin Zhao (zhao_bin@apple.com)
----***************************************************************
-------------------------------------------------------------------
require("Matchbox/plist2lua")

local Parser = {}
Log = require("Matchbox/Logging")
local record = require("Matchbox/record")

Parser.AttributeRecord = 0
Parser.ParametricRecord = 1
Parser.BinaryRecord = 2
TESTNAME_CONNECTOR = "%^"

-- Parse response with MD Parser
-- @param paraTab: parameters from tech csv line(table)
-- @return: result(true/false), pData(string, table)

function Parser.mdParse(paraTab, resp)
    Log.LogInfo("Running MD parser")

    -- local result = false
    -- local inputVar = paraTab.getInput()

    -- if resp == nil then
    --     if inputVar ~= nil and inputVar ~= "" and globalVarTab[inputVar] ~= nil then
    --         resp = globalVarTab[inputVar]
    --     else
    --         resp = globalVarTab["defaultOutput"]
    --     end
    -- end

    -- result = resp and true or false

    -- Parse DUT response
    -- local pData = nil
    -- if result then
    local mdParser = Device.getPlugin("MDParser")
    
    result, pData = xpcall(mdParser.parse, debug.traceback, paraTab.Commands, resp)
    Log.LogInfo(result, pData)

    -- end

    if not result then
        error("test failure: " .. tostring(pData))
    end
    return pData
end

-- Create record with Parser.createRecordWithTable
-- @param paraTab: parameters from tech csv line(table)
-- @return: result(true/false)

function Parser.createRecord(paraTab)
    local result = false
    -- local inputVar = paraTab.paralist["Input"]
    -- local input = nil
    -- if inputVar ~= nil and inputVar ~= "" and globalVarTab[inputVar] ~= nil then
    --     input = globalVarTab[inputVar]
    -- else
    --     input = globalVarTab["defaultOutput"]
    -- end

    -- result = input and true or false

    -- if type(input) ~= "table" then
    --     local paraName = paraTab.paralist["paraName"]
    --     if paraName == nil then
    --         error("no paraName in parameter")
    --     end
    --     input = { [tostring(paraName)] = input } -- Add suffix to avoid duplication of records from Tech.lua
    -- end
    result = Parser.createRecordWithTable(paraTab, {paraTab.getInput()})
    if not result then
        error("test failure")
    end
    return result
end

-- Create records based on data table
-- @param dataTable: data table with full definition of test names, limits, type...
-- @return true/false: result of creating records and failures records

function Parser.createRecordWithData(dataTable)
    if type(dataTable) ~= "table" then
        error("table expected for createRecordWithData: " .. tostring(dataTable))
    end

    local result = true

    for _, pData in ipairs(dataTable) do
        local testName = pData["testname"]
        local subTestName = pData["subtestname"]
        local subSubTestName = pData["subsubtestname"]
        local pResult = pData["result"]
        local value = pData["value"]
        local lowerlimit = pData["lowerlimit"]
        local relaxedlowerlimit = pData["relaxedlowerlimit"]
        local upperlimit = pData["upperlimit"]
        local relaxedupperlimit = pData["relaxedupperlimit"]
        local units = pData["units"]
        local priority = pData["priority"]
        local type = pData["type"]
        local failureMsg = pData["failuremessage"]
        local report = nil
        local nameTable = {}

        if pResult == true or string.lower(tostring(pResult)) == "pass" then
            pResult = true
        else
            pResult = false
        end

        if testName == nil or testName == "" then
            error("invalid data table, no testname defined: " .. tostring(testName))
        elseif subTestName == nil or subTestName == "" then
            nameTable = { testName }
        elseif subSubTestName == nil or subSubTestName == "" then
            nameTable = { testName, subTestName }
        else
            nameTable = { testName, subTestName, subSubTestName }
        end

        if type == Parser.AttributeRecord then
            report = record.createAttribute(subSubTestName, value)
        elseif type == Parser.BinaryRecord then
            report = record.createBinaryRecord(pResult, table.unpack(nameTable))
        elseif type == Parser.ParametricRecord then
            report = record.createParametricRecord(tonumber(value), table.unpack(nameTable){
                relaxedlowerlimit = tonumber(relaxedlowerlimit)
            })
            -- if report and lowerlimit ~= nil or upperlimit ~= nil or units ~= nil then
            --     report.applyLimit(tonumber(relaxedlowerlimit), tonumber(lowerlimit), tonumber(upperlimit), tonumber(relaxedupperlimit), units)
            -- end
        else
            error("invalid record type, should be 0, 1 or 2" .. tostring(type))
        end

        pResult = pResult and report.getResult() ~= 0

        if pResult == true then
            report.addFailureReason("")
        elseif failureMsg then
            report.addFailureReason(failureMsg)
        end

        pResult = xpcall(DataReporting.submit, debug.traceback, report) and pResult
        result = pResult and result
    end

    return result
end



-- Create records based on paraTab, data table, attribute list and limit file
-- @param paraTab: tech csv parameters
-- @return true/false: result of creating records and failures records

function Parser.createRecordWithTable(paraTab, dataTable)
    local result = true

    if dataTable == nil then
        Log.LogError("empty data table: " .. tostring(paraTab.tech) .. ", " .. tostring(paraTab.testname) .. ", " .. tostring(paraTab.paralist["subsubtestname"]))
        return false
    end

    local pDataTab = {}

    for pKey, pValue in pairs(dataTable) do
        local pData = {}
        local testName = tostring(paraTab.Technology)
        local subTestName = tostring(paraTab.TestName)
        local subSubTestName = paraTab.AdditionalParameters["subsubtestname"] and paraTab.AdditionalParameters["subsubtestname"] .. pKey or pKey
        local pResult = true
        local report = nil
        if(tonumber(pValue)) then
            record.createParametricRecord(pValue, testName, subTestName, subSubTestName, paraTab.limit[subTestName][subSubTestName])
        else
            record.createBinaryRecord(pValue, testName, subTestName, subSubTestName, paraTab.limit[subTestName][subSubTestName])
        end
        -- Fetch limit
        -- local limit = Parser.fetchLimit(paraTab.limit, testName, subTestName, subSubTestName)
        -- if limit == nil then
        --     limit = {}
        -- end
        -- Reconstructing subTestName, subSubTestName
        -- Leave pKey as subSubTestName so no need to check which substring is attribute name from concatenated string with subTestName and subSubTestName when needs to create attribute
        -- subTestName = subSubTestName and subTestName .. " - " .. tostring(subSubTestName) .. testNameSuffix or subTestName
        -- subSubTestName = tostring(pKey)

        
        -- if limit.units == "string" then
        --     if pValue ~= limit.upperLimit then
        --         pResult = false
        --     end
        --     pData["type"] = Parser.BinaryRecord
        -- elseif limit.upperLimit == nil and limit.lowerLimit == nil then
        --     pData["type"] = Parser.ParametricRecord
        -- -- Limit is string
        -- elseif type(limit.upperLimit) == type("a") or type(limit.lowerLimit) == type("a") then
        --     -- Convert string to number here since it seems limits we get are always string when reading.
        --     if tonumber(limit.upperLimit) ~= nil or tonumber(limit.lowerLimit) ~= nil then
        --         pData["type"] = Parser.ParametricRecord
        --     elseif limit.upperLimit ~= nil and pValue == limit.upperLimit or limit.lowerLimit ~= nil and pValue == limit.lowerLimit then
        --         pResult = true
        --         pData["type"] = Parser.BinaryRecord
        --     else
        --         pData["type"] = Parser.BinaryRecord
        --         pResult = false
        --         result = false
        --     end
        --  -- Limit is number
        -- elseif type(limit.upperLimit) == type(1) or type(limit.lowerLimit) == type(1)  then
        --     pData["type"] = Parser.ParametricRecord
        -- else
        --     result = false
        --     error("Invalid limit definition")
        -- end

        -- pData["testname"] = testName
        -- pData["subtestname"] = subTestName
        -- pData["subsubtestname"] = subSubTestName
        -- pData["result"] = pResult
        -- pData["lowerlimit"] = limit.lowerLimit
        -- pData["upperlimit"] = limit.upperLimit
        -- pData["relaxedlowerlimit"] = limit.relaxedLowerLimit
        -- pData["relaxedupperlimit"] = limit.relaxedUpperLimit
        -- pData["units"] = limit.units
        -- pData["value"] = pValue

        -- table.insert(pDataTab, pData)

    end

    -- result = Parser.createRecordWithData(pDataTab) and result
    -- return result
end

-- fetch limits for specific test names
-- @param testName: Tech name
-- @param subTestName: Test name
-- @param subSubTestName: subsubtestname in tech csv
-- @return table: limit table for specified test names

function Parser.fetchLimit(limit, testName, subTestName, subSubTestName)
    if limit == nil then
        return nil
    end
    return limit[subSubTestName]
end

-- Run shell command with RunShellCommand plugin's run() api
-- @param paraTab: parameters from tech csv line(table)
-- @return: result(true/false)

function Parser.runShellCommand(paraTab)
    Log.LogInfo("Running sendShellCommand:"..paraTab.tech .. ", " .. paraTab.testname .. ", " .. tostring(paraTab.paralist["subsubtestname"]) .. ", cmd: '" .. tostring(cmd) .. "', timeout: '" .. tostring(timeout) .. "'")
    Device.updateProgress(paraTab.tech .. ", " .. paraTab.testname .. ", " .. tostring(paraTab.paralist["subsubtestname"]))

    local cmd = paraTab.Commands
    if cmd == nil then
       error("Invalid parameter! Commands not defined")
    end

    local timeout = paraTab.Timeout
    if timeout ~= nil then
       timeout = tonumber(timeout)
    end

    local run = require('RunShellCommand')
    local status, resp = xpcall(run.run, debug.traceback, cmd)
    Log.LogInfo("RunShellCommand Resp: " .. tostring(resp.output .. "; stderr: " .. tostring(resp.error)))
    --local report = DataReporting.createBinaryRecord(true, paraTab.Tech, paraTab.TestName, paraTab.paralist["subsubtestname"])
    --DataReporting.getPrimaryReporter().submit(report)

    return status
end

return Parser
