--Teardown.lua
local Log = require("Matchbox/logging")
local record = require("Matchbox/record")

local teardown = {}

function teardown.blobExtraFile(params)
	Log.LogInfo("******teardown.blobExtraFile******")

	local filePath = params.AdditionalParameters['path']
	local userPath = Device.userDirectory
	local saveToPath = string.gsub(userPath, '/user', '/system')
	Log.LogInfo("fielPath:"..filePath)
	Log.LogInfo("saveToPath:"..saveToPath)
	local runShellCommand = Device.getPlugin('RunShellCommand')
	local cmd = 'cp -rf '..filePath..' '..saveToPath
	runShellCommand.run(cmd)
	--local result = Archive.addPathName(filePath, Archive.when.now, saveToPath)
	record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
end

function teardown.logCollect( params )
	Log.LogInfo("******teardown.logCollect******")
	-- body
	local runShellCommand = Device.getPlugin('RunShellCommand')
	runShellCommand.run('sudo log collect --last 5m --output ~/Desktop --size 100m')
	record.createBinaryRecord(true, params.Technology, params.TestName, params.AdditionalParameters["subsubtestname"], '')
end


return teardown