-------------------------------------------------------------------
----***************************************************************
----DUT Action Functions
----Created at: 07/21/2020
----Author: Bin Zhao (zhao_bin@apple.com)
----***************************************************************
-------------------------------------------------------------------

local ActionFunc = {}

local parser = require("Tech/Parser")
local dutCommChannelMux = require("Tech/DutCommMux")
local Log = require "Matchbox/logging"
local comFunc = require "Matchbox/CommonFunc"
local record = require "Matchbox/record"

local pVarName = '(%s*([0-9a-zA-Z-_]+)%s*)'
local pVarNameLocal = '^%('..pVarName..'%)$'
local pVarNameGlobal = '^%['..pVarName..'%]$'
local pVarNameCondition = '^%{'..pVarName..'%}$'


local function hex2str(hex)
    local str, n = hex:gsub("(%x%x)[ ]?", function (word)
        return string.char(tonumber(word, 16))
    end)
    return str
end

local function str2hex(str)
    local hex, n = str:gsub("(.)", function (char)
        return string.format("%02X", string.byte(char, 1, 1))
    end)
    return hex
end

-- for Input and Output varname parsing.
-- get real varname using given pattern;
-- if there is spaces around varname, report error.
local function getVarName(name, pattern)
    local nameWithPossibleSpaces, realName = name:match(pattern)
    if nameWithPossibleSpaces ~= realName then
        error(name..' unexpected space around variable name')
    end
    return realName
end

-- check whether given name represents a global variable.
-- Global variable is a variable name wrapped by a []
-- Global variable name cannot include [ or ].
-- return the actual name without [] if yes.
-- return nil when it is not.
local function nameIsGlobal(name)
    return getVarName(name, pVarNameGlobal)
end

-- check whether given name represents a local variable.
-- Local variable is a variable name wrapped by a ()
-- Local variable name cannot include ( or ).
-- return the actual name without () if yes.
-- return nil when it is not.
local function nameIsLocal(name)
    return getVarName(name, pVarNameLocal)
end


-- check whether given name represents a condition.
-- Condtion is a variable name wrapped by a {}
-- Condition name cannot include { or }.
-- return the actual name without {} if yes.
-- return nil when it is not.
local function nameIsCondition(name)
    return getVarName(name, pVarNameCondition)
end

-- return variable name type and varname for Input and Output.
-- TODO: handle case for (A)-(B) which is a string, not a local.
local SCOPE_LOCAL = 'Local Variable'
local SCOPE_GLOBAL = 'Global Variable'
local SCOPE_CONDITION = 'Condition'
local function checkVariableName(name)
    local ret = nameIsGlobal(name)
    if ret then return SCOPE_GLOBAL, ret end
    ret = nameIsCondition(name)
    if ret then return SCOPE_CONDITION, ret end
    ret = nameIsLocal(name)
    if ret then return SCOPE_LOCAL, ret end
    -- not an variable.
    return 'string', name
end

-- Run DUT Command
-- @param paraTab: parameters from tech csv line(table)
-- @return: command response(string)

function ActionFunc.sendCmd(paraTab, sendAsData)

    local sendCommand__inner = function ()
        local dut, hangDetector = dutCommChannelMux.getCurrentDataChannel(paraTab)
        if dut.isOpened() ~= 1 then
            dut.open(60)
        end
        local timeout = paraTab.Timeout and paraTab.Timeout ~= "" and tonumber(paraTab.Timeout) or nil

        local cmd = paraTab.Commands
        local cmdReturn = ""
        Device.updateProgress(paraTab.Technology .. ", " .. paraTab.TestName .. ", " .. tostring(paraTab.AdditionalParameters["subsubtestname"]))
        if cmd ~= nil then
            local hangTimeout = paraTab.AdditionalParameters["hangTimeout"]
            if hangTimeout ~= nil then
                Log.LogInfo("Setting HangTimeout:"..paraTab.Technology .. ", " .. paraTab.TestName .. ", " .. tostring(paraTab.AdditionalParameters["subsubtestname"]) .. ", HangTimeout: '" .. tostring(hangTimeout) .. "'")
                hangDetector.setHangTimeout(tonumber(hangTimeout))
            end

            if cmd == "shutdown" then
                dut.setDelimiter("Waiting for VBUS removal before shutting down.")
            end
            
            if sendAsData == nil or tonumber(sendAsData) == 0 then
                -- Send cmd and retrieve response as String
                Log.LogInfo("sending command now...")
                cmdReturn = dut.send(cmd, timeout)
            else
                -- Send cmd and retrieve response as Data, be sure to register Utilities plugin for device first.
                local Utilities = Device.getPlugin("Utilities")
                local cmdData = Utilities.dataFromHexString(str2hex(cmd))
                local returnData = dut.sendData(cmdData, timeout)
                cmdReturn = hex2str(Utilities.dataToHexString(returnData))

            end
        end

        return cmdReturn
    end

    -- sendCommand__inner()
    local status, ret = xpcall(sendCommand__inner, debug.traceback)

    if not status then
        -- Set hang_detected condition to "1"
        if string.match(ret or "", "HangDetected") ~= nil then
            error("Hang Detected")
        end
    end

    -- Check if matches expect string
    local expect = paraTab.AdditionalParameters["expect"]
    if expect ~= nil and string.match(ret or "", string.gsub(expect, "([%^%$%(%)%%%[%]%+%-%?])", "%%%1")) == nil then
        status = false
        error("expected string '" .. tostring(expect) .. "' not found in response: " .. tostring(ret))
    end

    if not status then
        error("test failure, please check log details")
    end
    record.createBinaryRecord(status, paraTab.Technology, paraTab.TestName, paraTab.AdditionalParameters.subsubtestname)
    return ret
end


-- Run DUT Command and receive response as Data
-- @param paraTab: parameters from tech csv line(table)
-- @return: command response(string)
function ActionFunc.sendData(paraTab)
    return ActionFunc.sendCmd(paraTab, 1)
end

-- Send command, parse response with MD Parser and create records
-- @param paraTab: parameters from tech csv line(table)
-- @return: result(true/false)

function ActionFunc.sendAndParseCommand(paraTab)
    -- Get DUT response
    local result = false
    local resp = nil
    local cmd = paraTab.Commands
    local sendCommand = cmd and cmd ~= "" and true or false

    if not sendCommand then
        error("no Commands defined")
    end

    result, resp = xpcall(ActionFunc.sendCmd, debug.traceback, paraTab)

    -- Parse DUT response
    local pData = nil
    if not result or resp == nil then
        error("sendCmd failed: " .. tostring(resp))
    end

    result, pData = xpcall(parser.mdParse, debug.traceback, paraTab, resp)
    if not result then
        error("sendAndParseCommand failed: " .. tostring(pData))
    end

    if paraTab.AdditionalParameters["auto-record"] then
        for k, v in pairs(pData) do
            local subsubtestname = paraTab.AdditionalParameters.subsubtestname and paraTab.AdditionalParameters.subsubtestname .."_" .. k or k
            -- if tonumber(v) and paraTab.limit then
            if tonumber(v) then
                if paraTab.limit then
                    record.createParametricRecord(tonumber(v), paraTab.Technology, paraTab.TestName, subsubtestname , paraTab.limit[subsubtestname])
                else
                    record.createParametricRecord(tonumber(v), paraTab.Technology, paraTab.TestName, subsubtestname , nil)
                end
            else
                record.createBinaryRecord(v ~= false, paraTab.Technology, paraTab.TestName, subsubtestname)
            end
        end
    end

    -- parse Output
    local outputs = comFunc.splitBySeveralDelimiter(paraTab.Output, ',')
    Log.LogDebug('Outputs: ' .. comFunc.dump(outputs))

    local outputVariables = {}
    for _, output in ipairs(outputs) do
        output = comFunc.trim(output)
        local _, varName = checkVariableName(output)
        if (pData[varName]) then
            table.insert(outputVariables, pData[varName])
        else
            error("sendAndParseCommand failed: " .. varName .. " is not valid from parsing results")
        end
    end
    return table.unpack(outputVariables)
end

-- Send command, parse response with LuaParser Module and create records
-- @param paraTab: parameters from tech csv line(table)
-- @return: result(true/false)

-- pending fix
-- function ActionFunc.sendAndParseCommandWithRegex(paraTab)
--     -- Get DUT response
--     local result = false
--     local resp = nil
--     local cmd = paraTab.Commands
--     local sendCommand = cmd and cmd ~= "" and true or false
 
--     if not sendCommand then
--         error("no Commands defined")
--     end
 
--     result, resp = xpcall(ActionFunc.sendCmd, debug.traceback, paraTab)
 
--     -- Parse DUT response
--     local pData = nil
--     if not result or resp == nil then
--         error("sendAndParseCommandWithRegex failed " .. tostring(resp))
--     end
    
--     if paraTab.paralist["pattern"] == nil  then
--         error("pattern not set")
--     end
    
--     -- Construct paraTab for csvCommon.parse
--     local inputVar = "sendAndParseCommandWithRegex"
--     local outputVar = paraTab.paralist["Output"]
--     local newParaTab = utils.clone(paraTab)
--     newParaTab.paralist["Input"] = inputVar

--     -- Workaround for csvCommon.parse before <rdar://problem/67799480> is fixed, since it's calling localVarTab declared in other files. 
--     local globals = Device.fetchPlugin("VariableTable")
--     globals.setVar(inputVar, resp)
--     localVarTab = localVarTab and localVarTab or globals.list()
--     result, pData = xpcall(csvCommon.parse, debug.traceback, newParaTab)
  
--     if not result then
--         error("sendAndParseCommandWithRegex failed: " .. tostring(pData))
--     end

--     if outputVar ~= nil then
--         local output = localVarTab[tostring(outputVar)]
--         pData = output and output or localVarTab["defaultOutput"]
--     end

--     return pData
-- end

function ActionFunc.syncCmdResp(paraTab)
    local echo = "echo_clear_buffer_to_send_string_and_poll"
    local dut, _ = dutCommChannelMux.getCurrentDataChannel(paraTab)
    if dut == nil then
        error("No valid dut communication channel activated")
    end
    local timeout = paraTab.Timeout and tonumber(paraTab.Timeout) or 1
    dut.write(echo)
    dut.read(timeout, echo) -- read command echo
    dut.read(timeout, echo) -- read command response
    dut.read(timeout) -- clear cache
end

return ActionFunc
