

local Log = require("Matchbox/logging")
local comFunc = require("Matchbox/CommonFunc")

local initialize = {}

initialize.loops_per_detection = 1

-- Setup View in Plugins.getSlots()
function initialize.getSlots(group_plugins)
    Log.LogInfo("--------getSlots-------")
    -- Retrieve slots from detect.lua
    local default_units = Group.getSlots()
    -- os.execute('sleep 5')
    Log.LogInfo('[DEBUG]waiting......')
    local detector = group_plugins['startDetector']
    detector.waitDetectDone()
    return default_units
    -- return {'slot1'}
end

function initialize.loadGroupPlugins(resources)
    Log.LogInfo("--------loadGroupPlugins-------")
    local InteractiveView = Remote.loadRemotePlugin(resources["InteractiveView"])
    local detector = Atlas.loadPlugin("MyDemoSocketDetector")
    local config = {}
    config['ip']= "127.0.0.1"
    config['port'] = 12321
    detector.createDetector(config)
    return {
      InteractiveView = InteractiveView,
      startDetector = detector
    }
end

-- Teardown DUT level plugins
function initialize.shutdownPlugins(plugins)
  Log.LogInfo("--------shutdown Plugins-------")
end

-- Teardown Group level plugin
function initialize.shutdownGroupPlugins(device_plugins)
    Log.LogInfo("--------shutdown Group Plugins-------")
end

function initialize.groupShouldExit()
  Log.LogInfo("--------Plugins.groupShouldExit()-------")
  return true
end

function initialize.loadPlugins(device, groupPlugins)
  Log.LogInfo("*****loadPlugins*****")
  local plugins = {}
  -- base plugins
  plugins['BPfixture'] = Atlas.loadPlugin("BPFixture")
  plugins['regex'] = Atlas.loadPlugin("Regex")
  plugins['stationInfoPlugin'] = Atlas.loadPlugin("StationInfo")
  plugins['SFC'] = Atlas.loadPlugin("SFC")
  plugins['Utilities'] = Atlas.loadPlugin("Utilities")
  plugins['RunShellCommand'] = Atlas.loadPlugin("RunShellCommand")
  -- MDParser plugin
  mdparser = Atlas.loadPlugin("MDParser")
  mdparser.init(Atlas.assetsPath .. "/parseDefinitions")
  plugins['MDParser']  = mdparser
  Log.LogInfo("*****loadPlugins done*****")

  
  return plugins
end

return initialize