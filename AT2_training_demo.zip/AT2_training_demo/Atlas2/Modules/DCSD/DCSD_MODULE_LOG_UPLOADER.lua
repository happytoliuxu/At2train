
-- constants
local BURNIN_STATION_ID = "BURNIN"
local BURNIN_TIME_STAMP_FORMAT = "yyyy-MM-dd HH:mm:ssZ"

local dcsd_util = require "DCSD/DCSD_UTILITY"

local M = {}

local function is_binary_record(record)
    if record["value"] == nil then
        return true
    -- temp workaround for <rdar://problem/57869160>: if value is "NA" or non-numerical string, convert to binary record
    elseif tonumber(record["value"]) == nil then
         return true
     end

    return false;
end

local function is_pass_binary(record)
    return record["result"] == "PASS"
end

local function get_parametric_value(record)
    return tonumber(record["value"])
end

local function get_record_info(record, key)
    if record[key] == "NA"
    then
        return nil
    else
        return record[key]
    end
end

local function record_info_string(record, key)
    if record[key] == nil then
        return "NIL"
    end
    return record[key]
end

local function report_parametrics(records)
    for _, record in pairs(records) do

        report = nil
        if is_binary_record(record) then
            -- print("Binary("..record_info_string(record, "testname")
            --                .."/"..record_info_string(record, "subtestname")
            --                .."/"..record_info_string(record, "subsubtestname")
            --                ..") = "..record_info_string(record, "result"))
            report = DataReporting.createBinaryRecord(is_pass_binary(record),
                                                      get_record_info(record, "testname"),
                                                      get_record_info(record, "subtestname"),
                                                      get_record_info(record, "subsubtestname"))
        else
            -- print("Perametric("..record_info_string(record, "testname")
            --                    .."/"..record_info_string(record, "subtestname")
            --                    .."/"..record_info_string(record, "subsubtestname")
            --                    ..") = "..record_info_string(record, "value"))
            report = DataReporting.createParametricRecord(get_parametric_value(record),
                                                          get_record_info(record, "testname"),
                                                          get_record_info(record, "subtestname"),
                                                          get_record_info(record, "subsubtestname"))
            report.applyLimit(tonumber(get_record_info(record, "lowerlimit")),
                              tonumber(get_record_info(record, "upperlimit")),
                              get_record_info(record, "units"))
        end

        DataReporting.submit(report)
    end
end

local function submit_data_to_current_station(pdca_dict, blob_path)
    local attributes = pdca_dict["Attributes"]
    local records    = pdca_dict["Tests"]
    local overall_results = pdca_dict["overallresult"] -- TODO: what to do with this?
    -- local reporter = DataReporting.getPrimaryReporter()

    dcsd_util.report_attributes(attributes)
    report_parametrics(records)
    -- if blob_path then
    --     print("copying " .. blob_path .. " to working directory of " .. Device.workingDirectory)
    --     dcsd_util.execute_shell_command('cp -r "' .. blob_path .. '" "' .. Device.workingDirectory .. '"')
    -- end
end

local function submit_data_to_other_station(pdca_dict, blob_path)
    local attributes = pdca_dict["Attributes"]
    local records    = pdca_dict["Tests"]
    local sub_station_id = attributes["SUB_STATION_ID"] -- will be used for creating blob
    local dutPosition = pdca_dict["DutPosition"]
    local overall_results = pdca_dict["overallresult"]

    dcsd_util.print_table(attributes)

    print("submitting data to other station: " .. sub_station_id)
    -- local my_burnin_reporter = DataReporting.createReporter()
    local station_id = attributes["STATION_ID"]

    if station_id == nil then
        print("STATION_ID is nil, using BURNIN")
        station_id = BURNIN_STATION_ID
    end

    -- my_burnin_reporter.start()

    DataReporting.primaryIdentity(attributes["serialnumber"])
    attributes["serialnumber"] = nil

    -- -- <rdar://problem/52093538> Atlas2 MLC overlay cannot put RUNIN logs under BURNIN/BURNIN on insight
    -- -- commented below out and try upload sub station id as a normal attribute.
    -- -- still discussing with Ramzy to see whether we want to update the stationName command
    -- my_burnin_reporter.stationName(station_id, sub_station_id)
    dcsd_util.report_attribute("STATION_IDENTIFIER", station_id) -- in case this is needed
    dcsd_util.report_attribute("STATION_SUB_IDENTIFIER", sub_station_id) -- STATION_SUB_IDENTIFIER should come from some constants
    attributes["STATION_ID"] = nil
    attributes["SUB_STATION_ID"] = nil

    local limit_version = attributes["limitsversion"];
    if limit_version == nil then
        print("No limit version is provided, using SW version as limit version")
        limit_version = attributes["softwareversion"]
    end

    DataReporting.softwareInfo(attributes["softwarename"], attributes["softwareversion"], limit_version)
    attributes["softwarename"] = nil
    attributes["softwareversion"] = nil
    attributes["limitsversion"] = nil

    dcsd_util.report_attributes(attributes)

    print("uploading BURNIN parametric data")
    report_parametrics(records)
    print("uploaded BURNIN parametric data")


    if dutPosition then

        print("uploading fixtureID/fixtureHeadID")

        if dutPosition["fixtureID"] == nil then
            dutPosition["fixtureID"] = "Unknown"
        end

        if dutPosition["fixtureHeadID"] == nil then
            dutPosition["fixtureHeadID"] = "Unknown"
        end

        dcsd_util.report_fixture_id(dutPosition["fixtureID"], dutPosition["fixtureHeadID"])
    end

    -- <rdar://problem/8921337> Log Collection: Report appropriate test time for untethered tests
    -- <rdar://problem/24977697> DCSD add support to read timezone from PDCA.plist
    -- Below is with the assumption that: if startTime/endTime is not set, InstantPudding will use the time on the station
    local seconds_6_months = 6*30*24*60*60
    if pdca_dict["startTime"] and pdca_dict["stopTime"] then
        print("startTime = "..pdca_dict["startTime"]..", stopTime == "..pdca_dict["stopTime"])
        DataReporting.startTime(pdca_dict["startTime"], BURNIN_TIME_STAMP_FORMAT)
        DataReporting.stopTime(pdca_dict["stopTime"], BURNIN_TIME_STAMP_FORMAT)
    end

    if blob_path then
        print("adding blob of " .. blob_path)
        dcsd_util.report_blob(sub_station_id, blob_path)
    end

    -- my_burnin_reporter.finish()

    print("finish submitting data to " .. sub_station_id .. ", with overall_results " .. overall_results)

    if overall_results == "PASS" then
        return true
    else
        return false
    end

end

function M.parse_log_folder_and_submit_data(dcsd_plugin, path, basename, device_type, ecid)
    local multi_pdca_dict = dcsd_plugin.parse_log_folder(path, device_type, ecid)
    local first_dict = true;
    local all_pass = true;

    for _, pdca_dict in pairs(multi_pdca_dict) do

        local attributes = pdca_dict["Attributes"]
        local station_id = attributes["STATION_ID"] and attributes["STATION_ID"] or BURNIN_STATION_ID
        local sub_station_id = attributes["SUB_STATION_ID"]
        local serial_number = attributes["serialnumber"]
        local other_station_result = true;

        if not station_id or not sub_station_id then
            print("logs are targeting to current station, will submit to current station")
            submit_data_to_current_station(pdca_dict, first_dict and path or nil)
        else
            print("SUB_STATION_ID=="..sub_station_id..", will submit to the target station")
            other_station_result = submit_data_to_other_station(pdca_dict, first_dict and path or nil)
            all_pass = all_pass and other_station_result
        end

        first_dict = false

    end

    return all_pass;

end

return M
