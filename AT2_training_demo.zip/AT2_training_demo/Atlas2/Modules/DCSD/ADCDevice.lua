require "DCSD/NONUIDevice"
ADCDevice = NONUIDevice:new()

function ADCDevice:new(transport)
    local adc_device = {}
    setmetatable(adc_device, self)
    self.dut = require "ADCDutPlugin"
    self.dut.setURL(transport)
    self.__index = self
    return adc_device
end

function ADCDevice:run_command(command, args, ignore_result, timeout, logging)
    print("running ADC command: " .. command .. " " .. table.concat(args or {}, " "))
    local remote_task = self.dut.createRemoteTask()
    if not timeout then timeout = 10 end
    if not logging then logging = true end
    remote_task.setExecutablePath(command)
    remote_task.setArguments(args)
    if ignore_result then
        remote_task.launch()
        print("this command doesnt need the result, returning success immediately")
        return 0
    end
    local termination_status = remote_task.runUntilExit(timeout)
    local _,stdout = pcall(remote_task.readStdoutBuffer)
    local _,stderr = pcall(remote_task.readStderrBuffer)
    if logging then
        print("result: " .. tostring(termination_status))
        print("stdout: " .. (stdout or ""))
        print("stderr: " .. (stderr or ""))
    end
    return termination_status
end
