require "DCSD/ADCDevice"
require "DCSD/FDCDevice"
local log_uploader = require "DCSD/DCSD_MODULE_LOG_UPLOADER"
local env = require "DCSD/DCSD_DEFINES"
local dcsd_util = require "DCSD/DCSD_UTILITY"

local TOOL_NAME_COPY_LOGS = "copyLogs"
local TOOL_NAME_COPY_UNRESTRICTED = "copyUnrestricted"
local TOOL_NAME_SZFILECOPY = "FactorySupportSZFileCopy"

LogCollector = {}

local FOLDER_NAME_LOGCOLLECTOR = "LogCollector"
-- we should try to unify the methods (copyLogs, renaming semaphore files, etc)
--               or find a better way to do the control instead of relying on type
LogCollector.device_type = env.DEVICE_TYPE_DEFAULT
LogCollector.device_sn = nil
LogCollector.device_log_folder = nil
LogCollector.device_usb_location = nil
LogCollector.host_destination_folder = nil
LogCollector.device_in_nonui = true

function LogCollector:new(device_type, device_usb_location, device_in_nonui, device_sn)
    local handler = {}

    setmetatable(handler, self)
    print("creating LogCollector: " .. device_type .. "," .. device_usb_location)
    self.device_type = device_type
    self.device_usb_location = device_usb_location
    self.device_in_nonui = device_in_nonui
    if device_in_nonui then
        local nonui_dut = self:build_dut()
        self.device_sn = nonui_dut:getSN()
    elseif device_sn then
        self.device_sn = device_sn
    else
        error("device SN needs to be provided if device is not in NONUI-OS mode")
    end
    local host_destination_folder = env.DATA_COLLECTION_FOLDER .. "/" .. (self.device_sn or device_usb_location) .. "/" .. os.date("%Y%m%d-%H%M%S")
    local HOME = string.gsub(io.popen("echo ~"):read("*all"),"\n","")
    host_destination_folder = string.gsub(host_destination_folder, "~", HOME)
    self.host_destination_folder = host_destination_folder
    if device_type == env.DEVICE_TYPE_MAC then
        self.device_log_folder = env.UNIT_LOG_FOLDER_MAC
    elseif device_type == env.DEVICE_TYPE_WATCH_SWDL then
        self.device_log_folder = env.SWDL_DEVICE_LOG_FOLDER
        self.host_destination_folder = Device.workingDirectory .. env.SWDL_LOG_HOST_FOLDER .. (self.device_sn or device_usb_location) .. "/" .. os.date("%Y%m%d-%H%M%S")
    elseif device_type == env.DEVICE_TYPE_WATCH_MOLOTOV then
        self.device_log_folder = env.MOLOTOV_DEVICE_LOG_FOLDER
        self.host_destination_folder = Device.workingDirectory .. env.MOLOTOV_LOG_HOST_FOLDER
    elseif device_type == env.DEVICE_TYPE_WATCH_BONFIRE then
        self.device_log_folder = env.BONFIRE_DEVICE_LOG_FOLDER
        self.host_destination_folder = Device.workingDirectory .. env.BONFIRE_LOG_HOST_FOLDER
    else
        self.device_log_folder = env.UNIT_LOG_FOLDER
    end
    self.__index = self

    return handler
end

function LogCollector:build_dut()
    print("building dut for " .. self.device_usb_location)
    return dcsd_util.build_nonui_device(self.device_type, self.device_usb_location)
end

function copy_logs_with_sz_file_copy(usb_location_str, source_folder, destination_folder)
    print("copy logs from unit to " .. destination_folder)

    local CFSErrorCodeEnableLogCollectionFailed = 200
    local command =  env.DCSD_TOOL_FOLDER .. "/" .. TOOL_NAME_SZFILECOPY .. " -l ".. usb_location_str .. " -s " .. source_folder .. " -d " .. destination_folder
    local copy_result = dcsd_util.execute_shell_command(command)
    -- according to Ken, we should ignore 202 and 200 which means there is no log or log partition
    -- on the device.
    if copy_result == 202 then
      print ("WARNING: logs not present on the device, ignoring log collection!!")
      return true
    elseif copy_result == CFSErrorCodeEnableLogCollectionFailed then
      print("Enable LogCollection failed, skipping LOG-COLLECTION")
      return true
    elseif copy_result ~= 0 then
        print("ERROR: " .. TOOL_NAME_SZFILECOPY .. " returned " .. tostring(copy_result))
        error("failed to copy logs with " .. TOOL_NAME_SZFILECOPY)
    end
    dcsd_util.execute_shell_command("rm -rf " .. destination_folder .. "/" .. source_folder .. "/META-INF")
    dcsd_util.execute_shell_command("mv " .. destination_folder .. "/" .. source_folder .. " " .. destination_folder .. "/" .. FOLDER_NAME_LOGCOLLECTOR)
    return true
end

local function copy_logs_with_atlasdevicectl(usb_location, source_folder, destination_folder)
    local command = "/usr/local/bin/atlasdevicectl copy"
    command = command .. " --locationID=" .. usb_location
    command = command .. " device:" .. source_folder
    command = command .. " " .. destination_folder .. "/" .. FOLDER_NAME_LOGCOLLECTOR

    local copy_result = dcsd_util.execute_shell_command(command)
    if copy_result ~= 0 then
        error("failed to copy logs with command: " .. command)
    end
end

local function copy_logs_with_tool(usb_location_str, tool_name, source_folder, destination_folder)

    print("copy logs from unit to " .. destination_folder)

    local command = "" .. env.DCSD_TOOL_FOLDER .. "/" .. tool_name .. " -u " .. usb_location_str .. " -t " .. destination_folder .. " -s " .. source_folder .. " -i 50"
    print("copying logs with command" .. command)
    local copy_result = dcsd_util.execute_shell_command(command)
    if copy_result == 113 then
        print(tool_name .. " returns 113, which means no log partition")
    elseif copy_result ~= 0 then
        error("failed to copy logs with tool " .. tool_name)
    end
    return true
end

function LogCollector:copy_logs_in_os_mode()
    if self.device_type == env.DEVICE_TYPE_MAC then
        copy_logs_with_atlasdevicectl(self.device_usb_location, self.device_log_folder, self.host_destination_folder)
    else
        copy_logs_with_tool(self.device_usb_location, TOOL_NAME_COPY_UNRESTRICTED, self.device_log_folder, self.host_destination_folder)
    end
end

function LogCollector:copy_logs_in_ramdisk_mode()
    if self.device_type == env.DEVICE_TYPE_MAC then
        copy_logs_with_sz_file_copy(self.device_usb_location, self.device_log_folder, self.host_destination_folder)
    else
        copy_logs_with_tool(self.device_usb_location, TOOL_NAME_COPY_LOGS, self.device_log_folder, self.host_destination_folder)
    end
end

function LogCollector:copy_logs_to_host()
    if self.device_in_nonui then
        print("copying logs from OS mode device")
        return self:copy_logs_in_os_mode()
    else
        print("copying logs from RamDisk device")
        return self:copy_logs_in_ramdisk_mode()
    end
end

local function rename_semaphore_file(dut, sub_folder, device_sub_folder)
    print("renaming semaphore files in device folder: " .. device_sub_folder)
    local semaphore_file = nil

    -- here assume semaphore file check is already done by dcsd plugin
    if dcsd_util.file_exist(sub_folder .. "/" .. env.SEMAPHORE_FLWTBC) then
        semaphore_file = env.SEMAPHORE_FLWTBC
    end

    if dcsd_util.file_exist(sub_folder .. "/" .. env.SEMAPHORE_FLTBPOH) then
        semaphore_file = env.SEMAPHORE_FLTBPOH
    end

    if not semaphore_file then
        print("no semaphore file needs to be updated in folder " .. device_sub_folder);
        return;
    end

    local origin_semaphore = device_sub_folder .. "/" .. semaphore_file
    local updated_semaphore = device_sub_folder .. "/" .. semaphore_file .. "." .. dcsd_util.get_current_date_string(env.BASIC_TIME_STAMP_FORMAT_LUA)
    local command = "/bin/mv " .. origin_semaphore .. " " .. updated_semaphore
    local result = dut:run_command("/usr/local/bin/bash", {"-c", command}, 10)

    if result ~= 0 then
        error("failed to update semaphore file for device_sub_folder: " .. device_sub_folder)
    end
end

function LogCollector:call_factorylineflow()
    if not self.device_in_nonui then
        error("device needs to be in NonUI when call factorylineflow")
    end

    local nonui_dut = self:build_dut()

    local factorylineflow_binary_path = "/usr/local/bin/factorylineflow"
    if not nonui_dut:exist_on_device(factorylineflow_binary_path) then
        print(factorylineflow_binary_path .. "doesn't exist on this device, skipping...")
        return
    end

    print("executing factorylineflow on device")
    local result = nonui_dut:run_command("/usr/local/bin/factorylineflow", {"finished", "--station-name", "LOG-COLLECTION"})

    if result ~= 0 then
        error("failed to run factorylineflow")
    end
end

-- @param hw_model  : optional. Only required for non-OS mode device
-- @param ecid      : optional. Only required for non-OS mode device
function LogCollector:process_host_logs(dcsd_plugin, hw_model, ecid)

    local all_pass = true
    local pfile = io.popen('ls "' .. self.host_destination_folder .. '/' .. FOLDER_NAME_LOGCOLLECTOR .. '"')
    local nonui_dut = nil

    if self.device_in_nonui then
        print("device in OS mode, will proactively read HW model and ECID")
        nonui_dut = self:build_dut()
        hw_model = nonui_dut:hw_model()
        ecid = nonui_dut:ecid()
    end
    print("hw_model = " .. hw_model .. ", ecid = 0x" .. string.format("%016X", ecid))

    local b_logs_found = false
    for filename in pfile:lines() do
        b_logs_found = true
        local sub_folder = self.host_destination_folder .. "/" .. FOLDER_NAME_LOGCOLLECTOR .. "/" .. filename
        local device_sub_folder = self.device_log_folder .. "/" .. filename
        print("parsing log folder: " .. sub_folder)
        local test_result = log_uploader.parse_log_folder_and_submit_data(dcsd_plugin, sub_folder, filename, hw_model, ecid)
        print("test result of " .. device_sub_folder .. " is " .. (test_result and "PASS" or "FAIL"))
        all_pass = all_pass and test_result
        if self.device_in_nonui then
            rename_semaphore_file(nonui_dut, sub_folder, device_sub_folder)
        end
    end
    if not b_logs_found then
        print("no log has been found. No op.")
    end
    pfile:close()

    -- <rdar://problem/56886622> LogCollector should call factorylineflow
    local station_util = require "StationInfo"
    if station_util.station_type() == "LOG-COLLECTION" then
        if not all_pass then
            print("not all logs on device are pass, skip calling factorylineflow")
            return
        end
        self:call_factorylineflow()
    end

end

-- @param hw_model  : optional. Only required for non-OS mode device
-- @param ecid      : optional. Only required for non-OS mode device
function LogCollector:process_host_logs_PDCA(dcsd_plugin, hw_model, ecid)

    print("self.host_destination_folder => ", self.host_destination_folder)
    local all_pass = true
    local nonui_dut = nil
    if self.device_in_nonui then
        print("device in OS mode, will proactively read HW model and ECID")
        nonui_dut = self:build_dut()
        hw_model = nonui_dut:hw_model()
        ecid = nonui_dut:ecid()
    end
    print("hw_model = " .. hw_model .. ", ecid = 0x" .. string.format("%016X", ecid))
    local sub_folder = self.host_destination_folder
    local test_result = log_uploader.parse_log_folder_and_submit_data(dcsd_plugin, sub_folder, "", hw_model, ecid)
    local device_sub_folder = self.device_log_folder
    print("test result of " .. device_sub_folder .. " is " .. (test_result and "PASS" or "FAIL"))
    all_pass = all_pass and test_result
    if self.device_in_nonui then
        rename_semaphore_file(nonui_dut, sub_folder, device_sub_folder)
    end

    local station_util = require "StationInfo"
    if station_util.station_type() == "LOG-COLLECTION" then
        if not all_pass then
            print("not all logs on device are pass, skip calling factorylineflow")
            return
        end
        self:call_factorylineflow()
    end
end

function LogCollector:process_host_logs_PDCA_without_restore(dcsd_plugin, host_destination_folder, hw_model, ecid)
    print("host_destination_folder => ", host_destination_folder)
    -- print("hw_model = " .. hw_model .. ", ecid = 0x" .. string.format("%016X", ecid))
    local test_result = log_uploader.parse_log_folder_and_submit_data(dcsd_plugin, host_destination_folder, "", hw_model, ecid)
end

function LogCollector:delete_nvram_flag()
    local result = 0
    if self.device_type == env.DEVICE_TYPE_MAC then
        print("NVRAM restore is not enabled for Mac projects. Skipping deleting the flag")
        return
    end
    if self.device_in_nonui then
        local nonui_dut = self:build_dut()
        result = nonui_dut:run_command("/usr/sbin/nvram", {"-d", "prevent-restores"})
    else
        local command = env.DCSD_TOOL_FOLDER .. "/" .. TOOL_NAME_COPY_LOGS .. " -u " .. self.device_usb_location .. " --delete_prevent_restores"
        result = dcsd_util.execute_shell_command(command)
    end

    if result ~= 0 then
        error("failed to delete prevent-restores flag")
    end
end
