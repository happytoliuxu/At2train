require "DCSD/NONUIDevice"
FDCDevice = NONUIDevice:new()

local function try(f, catch_f)
    local status, exception = pcall(f)
    if not status and catch_f
    then
        catch_f(exception)
    end
end

function FDCDevice:new(transport)
    local fdc_device = {}
    setmetatable(fdc_device, self)
    self.dut = require "FDCDUTPlugin"
    self.dut.setURL(transport)
    self.__index = self
    return fdc_device
end

function FDCDevice:run_command(command, args, ignore_result, timeout, logging)
    local result = 0
    local stdout = nil
    local stderr = nil

    print("running FDC command: " .. command .. " " .. table.concat(args or {}, " "))

    if not timeout then timeout = 10 end
    if not logging then logging = true end

    local on_device_task = self.dut.createRemoteTask(command, args)
    local commBuilder = require "CommBuilder"
    local stdioChan  = commBuilder.createCommPlugin(on_device_task.stdioChannel())
    local stderrChan = commBuilder.createCommPlugin(on_device_task.stderrChannel())

    on_device_task.launch()
    if ignore_result then
        print("this command doesnt need the result, returning success immediately")
        return 0
    end
    result =  on_device_task.waitUntilExitWithTimeout(timeout)
    pcall( function() stdout = stdioChan.read(0.1) end )
    pcall( function() stderr = stderrChan.read(0.1) end )

    if logging then
        print("command return: " .. tostring(result))
        print("command stdout: " .. (stdout or "NA"))
        print("command stderr: " .. (stderr or "NA"))
    end

    return result, stdout, stderr

end
