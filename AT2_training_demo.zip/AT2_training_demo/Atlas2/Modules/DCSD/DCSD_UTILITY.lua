require "DCSD/ADCDevice"
require "DCSD/FDCDevice"
local constants = require "DCSD/DCSD_DEFINES"

local M = {}

function M.sleep(n)  -- seconds
    os.execute("sleep " .. tonumber(n))
end

function M.parentUSBPortAddress(n)
    local bit = n & -n;
    local low = bit / (bit%15);
    local nibble = low * 15;

    return (n & ~nibble);
end

function M.host_of_transport(transport)
    local URL = require("url")
    local host = URL.parse(transport).host
    return host
end

function M.try(f, catch_f)
    local status, exception = pcall(f)
    if not status and catch_f
    then
        catch_f(exception)
    end
end

function M.set_spartan_config(cable, config_path, save)
    local atde = require "ATDESupport"
    local cable_usb_transport = cable.usb_transport()
    print("load Spartan cable config file at: " .. config_path)

    local spartan_cable = nil
    M.try(
    function()
        spartan_cable = atde.createSpartanControlPlugin(cable_usb_transport)
    end,
    function(error)
        print("error creating spartan cable, error - " .. error)
    end)

    if not spartan_cable then
        print("cannot find spartan cable at " .. cable_usb_transport .. ", ignoring with NO-OP")
        return
    end

    spartan_cable.loadConfigurationFromFile(config_path, save)
    print("spartan cable configured")
end

function M.file_exist(path)
  local file = io.open(path, "rb")
  if file then
      file:close()
  end
  return file ~= nil
end

function M.load_dcsd_plugin(atlas_plugin_path)
    local dcsd_plugin = nil

    if M.file_exist(atlas_plugin_path .. "/DCSD_DOE.l-dylib") then
        dcsd_plugin = require "DCSD_DOE"
    elseif M.file_exist(atlas_plugin_path .. "/DCSD-DOE.l-dylib") then
        dcsd_plugin = require "DCSD-DOE"
    else
        dcsd_plugin = require "DCSD"
    end

    return dcsd_plugin
end

function M.load_settings(dcsd_plugin, settings_folder)
    local station_util = require "StationInfo"
    local _, station_type = pcall(station_util.station_type)
    local settings_file = settings_folder .. "/" .. station_type .. ".plist"
    print("loading settings file - " .. settings_file)
    local settings = dcsd_plugin.load_plist_file(settings_file)
    return settings
end

function M.table_keys(input_table)
    local output_keys = {}
    for k, v in pairs(input_table) do
        table.insert(output_keys, k)
    end
    return output_keys
end

function M.execute_shell_command(command)
    command = command .. " 2>&1"
    print("executing command: " .. command)
    local handle = io.popen(command)
    local result = handle:read("*all")
    print("command output: " .. result)
    local ret_dict = {handle:close()}
    local exit_code = ret_dict[3]
    print("command return code: " .. tostring(exit_code))
    return exit_code, result
end

function M.execute_shell_commands(commands, stop_on_fail)
    local all_pass = true

    if not stop_on_fail then
        stop_on_fail = true
    end

    for _,each_command in ipairs(commands) do
        local each_result = M.execute_shell_command(each_command)
        if each_result ~= 0 and stop_on_fail then
            return false
        elseif each_result ~= 0 then
            all_pass = false
        end
    end

    return all_pass
end

function M.get_current_date_string(format)
    local Date = require("pl.Date")
    local start_date = Date()
    local date_formatter = Date.Format(format)
    local date_string = date_formatter:tostring(start_date)
    print("current date is " .. date_string)
    return date_string
end

function M.print_table(table)
    if not table then
        print("[WARNING] trying to print a nil table")
        return
    end
    local pretty = require("pl.pretty")
    table_string = pretty.write(table)
    print(table_string)
end

function M.start_logging_uart(uart_transport, log_file)
    if not uart_transport then
        print("no uart_transport availabe, skipping")
        return nil
    end

    print("start uart logging for "..uart_transport .. " to file " .. log_file)
    local commBuilder = require "CommBuilder"
    commBuilder.setDelimiter("\n")
    commBuilder.setLogFilePath(log_file,nil)
    local logger = commBuilder.createCommLoggerPlugin(uart_transport)

    M.try(
        function() logger.open() end,
        function(error)
            print("failed to open " .. uart_transport .. ", error -" .. error)
            logger = nil
        end
    )

    return logger
end

function M.load_ramdisk_for_test(dcsd_dut, pr_doc, test_name)
        print("loading FactoryRamDisk for" .. test_name)
        local error_msg = nil

        M.try(
            function ()
                local progress = require "AtlasProgressChannel"
                Device.updateProgress("loading FactorySupportRamDisk for " .. test_name)
                dcsd_dut.load_factory_ram_disk(pr_doc, test_name, progress.get_plugin())
                progress.wait_until_finish()
                Device.updateProgress("successfully loaded FactorySupportRamDisk")
            end,
            function (error)
                error_msg = error.msg or error
            end
        )

        if error_msg then
            error(error_msg)
        end
end

function M.reboot_device_from_ramdisk(dcsd_dut, timeout)
    if not timeout then
        timeout = 60
    end

    if not dcsd_dut.in_ramdisk() then
        error("trying to reboot device from ramdisk while device is not in Ramdisk")
    end

    local progress = require "AtlasProgressChannel"
    Device.updateProgress("reboot device from FactoryRamDisk")
    dcsd_dut.reboot_from_ram_disk(timeout, progress.get_plugin())
    progress.wait_until_finish()
end

function M.reboot_on_disconnect(usb_location_str)
    local command = "/usr/local/bin/FactoryServicesHost -u " .. usb_location_str .. " -e REBOOT_ON_DISCONNECT"
    print("set REBOOT_ON_DISCONNECT with command \"" .. command .. "\"")
    M.execute_shell_command(command)
end

function M.shutdown_on_disconnect(usb_location_str)
    local command = "/usr/local/bin/FactoryServicesHost -u " .. usb_location_str .. " -e SHUTDOWN_ON_DISCONNECT"
    print("set SHUTDOWN_ON_DISCONNECT with command \"" .. command .. "\"")
    M.execute_shell_command(command)
end

function M.reboot_to_iefi_on_disconnect(dut, usb_location_str)

    dut:config_iefi_boot_settings()

    M.reboot_on_disconnect(usb_location_str)
end

function M.build_nonui_device(device_type, device_usb_location)
    local device = nil
    if device_type == constants.DEVICE_TYPE_MAC then
        device = ADCDevice:new("usb://" .. device_usb_location)
    else
        device = FDCDevice:new("usb://" .. device_usb_location)
    end
    return device
end

function M.process_control(dcsd_dut, failed_cb_plugin, is_start, device_type)
    local dut = nil
    local usb_location_str = M.host_of_transport(dcsd_dut.usb_transport())

    if dcsd_dut.mode() == dcsd_dut.OS_MODE
    and not dcsd_dut.has_ui()
    and not dcsd_dut.in_ramdisk() then
        local device = M.build_nonui_device(device_type, usb_location_str)
        dut = device.dut
    else
        print("device not in OS mode, will use DCSDPlugin to do process control")
        dut = dcsd_dut
    end

    if is_start then
        failed_cb_plugin.clearFailedCBInfo(Device.systemIndex)
        M.try(
            function() ProcessControl.startProcessControl(dut) end,
            function(error_msg)
                local failed_cb_info = ProcessControl.failedCBInfo()
                if failed_cb_plugin and next(failed_cb_info) ~= nil then
                    failed_cb_plugin.setFailedCBInfo(failed_cb_info, Device.systemIndex)
                end

                error(error_msg)
            end
            )

    else
        if ProcessControl.inProgress() then
            ProcessControl.finishProcessControl(dut)
        else
            print("Warning:ProcessControl.finishProcessControl skipped as startProcessControl wasn't invoked")
        end
    end
end

function M.report_attribute(key, value)
    print("reporting key " .. key .. " with value " .. value)
    DataReporting.submit(DataReporting.createAttribute(key, value))
    print("successfully report key:" .. key)
end

function M.report_attributes(attributes)
    if type(attributes) ~= "table" then
        print("attributes is not table in report_attributes")
        return
    end
    for attribute_key, attribute_value in pairs(attributes) do
        M.report_attribute(attribute_key, attribute_value)
    end
end

function M.report_pass_parametric(test, subtest, value)
    print("reporting parametric: test_name = "..test..", subtest_name = "..subtest..", value = "..tostring(value))
    local record = DataReporting.createParametricRecord(tonumber(value), test, subtest)
    DataReporting.submit(record)
end

function M.report_blob(key, blob_path)
    if blob_path then
        print("uploading blob at "..blob_path)
        local blob = DataReporting.createBlob(key, blob_path)
        repoDataReporting.submit(blob)
    end
end

function M.report_fixture_id(fixture_id, head_id)
    print("report fixture_id = " .. fixture_id .. ", head_id = " .. head_id)
    DataReporting.fixtureID(fixture_id, head_id)
end

function M.run_fdc_command(usb_url, command, args, timeout, logging)
    local result = 0
    local stdout = nil
    local stderr = nil

    local dut = require "FDCDUTPlugin"
    dut.setURL(usb_url)

    print("running FDC command: " .. command .. " " .. table.concat(args or {}, " "))

    if not timeout then timeout = 10 end
    if not logging then logging = true end

    local on_device_task = dut.createRemoteTask(command, args)
    local commBuilder = require "CommBuilder"
    local stdioChan  = commBuilder.createCommPlugin(on_device_task.stdioChannel())
    local stderrChan = commBuilder.createCommPlugin(on_device_task.stderrChannel())

    on_device_task.launch()
    result =  on_device_task.waitUntilExitWithTimeout(timeout)

    if logging then

        M.try(
            function()
                stdout = stdioChan.read(0.1)
            end
        )
        M.try(
            function()
                stderr = stderrChan.read(0.1)
            end
        )

        print("command return: " .. tostring(result))
        print("command stdout: " .. (stdout or "NA"))
        print("command stderr: " .. (stderr or "NA"))
    end

    return result, stdout, stderr

end

function M.run_fdc_commands(commands, stop_on_fail, timeout)
    local all_pass = true

    if stop_on_fail == nil then
        stop_on_fail = true
    end

    for _,each_command_dict in ipairs(commands) do
        local each_result = M.run_fdc_command(each_command_dict[1], each_command_dict[2], timeout)
        if each_result ~= 0 and stop_on_fail then
            return false
        elseif each_result ~= 0 then
            all_pass = false
        end
    end

    return all_pass
end

function M.run_ignore_error(func, ...)

    local status, exception = pcall(func, ...)

    if not status then
        print("[WARNING]: ignored exception - " .. exception)
    end
end

function M.parse_error(device_err_msg)

    if not device_err_msg then
        return nil
    end

    local start_pos = nil
    local end_pos = nil
    if string.find(device_err_msg, "NSLocalizedDescription") then -- NSError from a plugin
        _, start_pos = string.find(device_err_msg, 'NSLocalizedDescription = ')
        end_pos = string.find(device_err_msg, "[\n\r]", start_pos)
    elseif string.find(device_err_msg, ":%d+:") then -- error()
        local temp_err_msg = device_err_msg

        local temp_end = string.find(device_err_msg, "stack traceback:")
        if temp_end then
            temp_err_msg = string.sub(device_err_msg, 1, temp_end);
        end

        end_pos = string.len(temp_err_msg) - 1

        local reversed_err_msg = string.reverse(temp_err_msg)
        start_pos = string.find(reversed_err_msg, ":%d+:")
        start_pos = string.len(temp_err_msg) - start_pos + 1

    end

    if start_pos and end_pos then
        return string.sub(device_err_msg, start_pos+1, end_pos-1)
    end

    return device_err_msg
end

local function call_amIOK()
    if ProcessControl.inProgress() then -- we only want to call this when SN is set
        return ProcessControl.amIOK()
    end
    print("ProcessControl hasn't started yet or already finished, skip calling amIOK")
    return true
end

function M.run_action_main(action_name, func, continue_on_AmIOK_failure, ...)
    local status, exception = pcall(call_amIOK)
    if status or continue_on_AmIOK_failure then
        exception = nil
        status, exception = pcall(func, ...)
    end

    local error_msg = nil
    local binary = nil

    if not status then
        if type(exception) ~= "string" then
            exception = "Action (".. action_name .. ") has exception with wrong type : " .. type(exception)
        end
        print("Found exception - " .. exception)
        error_msg = M.parse_error(exception)
        if not error_msg or string.len(error_msg) == 0 then
            error_msg = "action (" .. action_name .. ") failed with no error message"
        end
        local subsubtestname = string.sub(error_msg, 1, 128)
        binary = DataReporting.createBinaryRecord(false, "DCSD", action_name, subsubtestname);
        local failure_reason = string.sub(error_msg, 1, 512)
        binary.addFailureReason(failure_reason)
    else
        binary = DataReporting.createBinaryRecord(true, "DCSD", action_name);
        exception = nil
    end
    DataReporting.submit(binary)

    return error_msg

end

return M
