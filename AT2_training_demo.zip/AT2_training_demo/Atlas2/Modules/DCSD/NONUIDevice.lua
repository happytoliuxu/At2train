NONUIDevice = {dut = nil}

function NONUIDevice:new()
    local device = {}
    setmetatable(device, self)
    self.__index = self
    return device
end

function NONUIDevice:run_command(command, args, ignore_result, timeout, logging)
    error("run_command has to be implemented");
end

function NONUIDevice:run_command_ignore_result(command, args, timeout, logging)
    return self:run_command(command, args, true, timeout, logging)
end

function NONUIDevice:exist_on_device(path)
    print("check the existence of " .. path)
    local command = "/bin/ls " .. path

    local retval = self:run_command("/usr/local/bin/bash", {"-c", command})
    return (retval == 0)
end

-- below commands now only works with FDC and ADC. We will need to copy them to
-- each of the subclass if we have more dut plugins
function NONUIDevice:ecid()
    return self.dut.readECID()
end

function NONUIDevice:hw_model()
    local model = self.dut.readDeviceModel()
    model = string.gsub(model, "AP", "")
    model = string.gsub(model, "DEV", "")
    return model
end

function NONUIDevice:getSN()
    return self.dut.getSN()
end

-- @param commands      : table of commands. In the format of {{<path> [, {<args>} [, <ignore_reuslt> [,<timeout> [, <logging>]]]] }
-- @param stop_on_fail  : whether to stop on fail. default true
-- return true when all pass, fail if any command failed (termination status not 0)
function NONUIDevice:run_commands(commands, stop_on_fail)
    local all_pass = true

    if stop_on_fail == nil then
        stop_on_fail = true
    end

    for _,each_command_dict in ipairs(commands) do
        local each_result = self:run_command(each_command_dict[1], -- path
                                             each_command_dict[2], -- args
                                             each_command_dict[3], -- ignore_result
                                             each_command_dict[4], -- timeout
                                             each_command_dict[5]) -- logging
        if each_result ~= 0 and stop_on_fail then
            return false
        elseif each_result ~= 0 then
            all_pass = false
        end
    end

    return all_pass
end

function NONUIDevice:config_iefi_boot_settings()
    local commands = {
        {"/usr/sbin/nvram", {"auto-boot=true"}},
        {"/usr/sbin/nvram", {"boot-command=diags"}},
        {"/usr/sbin/nvram", {"-s"}},
    }

    local result = self:run_commands(commands)

    print("Config boot settings for diags " .. (result and "PASS" or "FAIL"))

    return result
end

-- just trigger reboot without any wait
function NONUIDevice:reboot()
    print("rebooting device")
    self:run_command_ignore_result("/sbin/reboot")
    return true
end

-- just trigger shutdown without any wait
function NONUIDevice:shutdown()
    print("shutting down the device")
    self:run_command_ignore_result("/sbin/halt")
    return true
end

-- setting up auto-boot and boot-command and reboot the device
-- it will return right after trigger the reboot without waiting for the device to
-- enter diags
function NONUIDevice:reboot_for_iefi()
    local result = self:config_iefi_boot_settings()
    if result then
        self:reboot()
    end
end
