# Hints on the logger files


| Log File Name                                  | Purpose                                                                                                                                                              |
| :--------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| uart_kis.log                                   | kis dock channel 0 log, logging happens when receving line terminator "\n"                                                                                           |
| uart_ap.log                                    | APUART log, logging happens when receving line terminator "\n"                                                                                                       |
| Debug/processed_uart.log                       | general dut communication log, logging when receving frame terminator "] :-)" for diags, "SEGPE>" for rtos, ...                                                      |
| Debug/rawuart.log                              | general dut communication log, logging for every reading action                                                                                                      |
| UARTLogger_APUART/processed_uart_logger_ap.log | apuart logger log, logging happens when interaction with DUT happens on KIS DC, and logging when receving frame terminator "] :-)" for diags, "SEGPE>" for rtos, ... |
| UARTLogger_APUART/rawuart_logger_ap.log        | apuart logger log, logging happens when interaction with DUT happens on KIS DC, and logging for every reading action                                                 |
| UARTLogger_KIS/processed_uart_logger_kis.log   | kis logger log, logging happens when interaction with DUT happens on APUART, and logging forwhen receving frame terminator "] :-)" for diags, "SEGPE>" for rtos, ... |
| UARTLogger_KIS/rawuart_logger_kis.log          | kis logger log, logging happens when interaction with DUT happens on APUART, and logging for every reading action                                                    |