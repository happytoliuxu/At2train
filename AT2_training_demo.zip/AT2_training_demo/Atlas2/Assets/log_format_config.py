
""" Log Formatting
<TIMESTAMP><TEST_START_INDENTATION>testname<TEST_NAME_CONNECTOR>subtestname<TEST_NAME_CONNECTOR>subsubtestname
<TIMESTAMP><RECORD_INDENTATION><RECORD_PREFIX>...<RECORD_SUFFIX>
<TIMESTAMP><FIXTURE_CMD_INDENTATION><FIXTURE_CMD_PREFIX>...<FIXTURE_CMD_SUFFIX>
<TIMESTAMP><FIXTURE_RESP_INDENTATION><FIXTURE_RESP_PREFIX>...<FIXTURE_RESP_SUFFIX>
<TIMESTAMP><DUT_CMD_INDENTATION><DUT_CMD_PREFIX>...<DUT_CMD_SUFFIX>
<TIMESTAMP><DUT_RESP_INDENTATION><DUT_RESP_PREFIX>...<DUT_RESP_SUFFIX>
<TIMESTAMP><FLOW_DEBUG_INDENTATION><FLOW_DEBUG_PREFIX>...<FLOW_DEBUG_SUFFIX>
<TEST_SEPARATOR>


Example with default setting:


2021/09/30 15:35:05.944076    fixture_setup_2  | Setup |  mock multiple parametric
2021/09/30 15:35:05.944370             #record#           lower:       higher:       value: true                 unit:       msg: nil
2021/09/30 15:35:05.944688             #record#           lower:       higher:       value: 1                    unit:       msg: nil
2021/09/30 15:35:05.944968             #record#           lower:       higher:       value: 2                    unit:       msg: nil
2021/09/30 15:35:05.945271             #record#           lower:       higher:       value: 3                    unit:       msg: nil
2021/09/30 15:35:05.945501             #record#           lower:       higher:       value: Dummy String Result  unit:       msg: nil
2021/09/30 15:35:05.945530    PASS

2021/09/30 15:35:05.950293    fixture_setup_2    Setup    mock test with fixture & DUT interaction
2021/09/30 15:35:05.950479             #fixture command#  method: ralay_on args: {net: VBATT} timeout: 1000
2021/09/30 15:35:05.950508             #fixture response# done
2021/09/30 15:35:05.950533             #fixture command#  method: dmm   args: {net: VBATT} timeout: 1000
2021/09/30 15:35:05.950580             #fixture response# 4.0V
2021/09/30 15:35:05.950602             #dut command#      nvram --list
2021/09/30 15:35:05.950759             #dut response#     nonce-seeds = 208 bytes
2021/09/30 15:35:05.954659                                channel was stalled due to overlogging
2021/09/30 15:35:05.959318                                channel was stalled due to overlogging
2021/09/30 15:35:05.959462                                root-live-fs = 1
2021/09/30 15:35:05.959467                                idle-off = false
2021/09/30 15:35:05.959471                                debug-uarts = 3
2021/09/30 15:35:05.965460                                channel was stalled due to overlogging
2021/09/30 15:35:05.965575                                boot-args = battery-state=-1 debug=0x14e serial=3 smt amfi_allow_any_signature=1 cs_enforcement_disable=1 amfi_unrestrict_task_for_pid=1 marconi-conf=1 noidle=1 apfs_edt_rw_mount=1 usbcontroller=kis
2021/09/30 15:35:05.965582                                boot-breadcrumbs = 3000d f0200 3000c(74727374) 3000d 3000c(74727374) 40040006 4003000e <COMMIT> 4002000d(0) 3000c(74727374) 3000d f0008(72676678) f0200 f0201 f0100(72676678) f0104(72676678) 3000c(74727374) 3000d f0008(7273696f) f0200 f0009(7273696f) 3000c(74727374) 3000d 100004(c290) 100005(c290) 3000c(74727374) 3000d f0008(61636977) f0200 f0009(61636977) 3000c(74727374) 3000d f0008(61636962) f0200 f0009(61636962) 3000c(74727374) 3000d f0008(72616f70) f0200 f0009(72616f70) 3000c(7264736b) 3000d 3000c(72647472) 40029 3000d 3000c(0) 3000d 40038(948000) 40039(1890000) 4003a(0) 3000c(726b726e) 40029 3000d <DONE> <COMMIT>
2021/09/30 15:35:05.965587                                boot-command = diags
2021/09/30 15:35:05.965592                                auto-boot = false)
2021/09/30 15:35:05.966178             #record#           lower:       higher:       value: 1                    unit:       msg: nil
2021/09/30 15:35:05.966209    PASS

2021/09/30 15:35:05.986998    fixture_setup_3  |  Setup  |  mock parametric test
2021/09/30 15:35:05.987616             #record#           lower: 0     higher: 2     value: 1                    unit: nil   msg: nil
2021/09/30 15:35:05.987641    PASS

"""
# Content Prefix/Suffix
TEST_NAME_PREFIX = ""
TEST_RESULT_PREFIX = ""
RECORD_PREFIX = "#record#"
FIXTURE_CMD_PREFIX = "#fixture command#"
FIXTURE_RESP_PREFIX = "#fixture response#"
DUT_CMD_PREFIX = "#dut command#"
DUT_RESP_PREFIX = "#dut response#"
FLOW_DEBUG_PREFIX = "#flow debug#"

TEST_NAME_SUFFIX = ""
TEST_RESULT_SUFFIX = ""
RECORD_SUFFIX = ""
FIXTURE_CMD_SUFFIX = ""
FIXTURE_RESP_SUFFIX = ""
DUT_CMD_SUFFIX = ""
DUT_RESP_SUFFIX = ""
FLOW_DEBUG_SUFFIX = ""

TEST_SEPARATOR = "\n"

# Data Format
TIMESTAMP = "%Y/%m/%d %H:%M:%S.%f"
EXPORT_TIMESTAMP = TIMESTAMP
SUBTEST_NAME_CONNECTOR = " | "
SUBSUBTEST_NAME_CONNECTOR = " | "

# Content Indentation
TEST_START_INDENTATION = 2
TEST_RESULT_INDENTATION = 2
RECORD_INDENTATION = 9
FIXTURE_CMD_INDENTATION = 9
FIXTURE_RESP_INDENTATION = 9
DUT_CMD_INDENTATION = 9
DUT_RESP_INDENTATION = 9
FLOW_DEBUG_INDENTATION = 9

PREFIX_LEN = max(len(RECORD_PREFIX), len(FIXTURE_CMD_PREFIX), len(FIXTURE_RESP_PREFIX), len(DUT_CMD_PREFIX), len(DUT_RESP_PREFIX), len(FLOW_DEBUG_PREFIX))