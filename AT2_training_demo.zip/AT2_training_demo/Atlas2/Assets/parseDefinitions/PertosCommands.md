EFI parsing definition file
===========================

Version Info
------------
07/22/2020 ver 0.1

[TOC]

Commands that can be parsed
===========================

log init
----------
```
PASS log init
```

pmgr mode 0x0002255
----------
```
PASS pmgr mode 0x0002255
```

fuse ecid
----------
```
{{}} ECID Fuse : {{fuse_ecid}}
{{}}   Lot ID  : {{lot_id}}
{{}}   Wafer   : {{wafer_id}}
{{}}   X Pos   : {{x_pos}}
{{}}   Y Pos   : {{y_pos}}
PASS fuse ecid
```

fuse config
----------
```
{{}} Configuration fuse assignment
{{}}   {{Fuse_config}}
{{}}
{{}} Configuration fuse settings
{{}}   Fuse Rev     : {{fuse_rev}}
{{}}   Bincut Info Change Flag: {{fuse_bincut_info_change_flag}}
{{}}   Device Rev   : {{fuse_device_rev}}
{{}}   Prod id      : {{fuse_prod_id}}
{{}}   CPU IDS      : {{fuse_cpu_ids_dig}},{{/([ ]+)/}}{{fuse_cpu_ids_ana}} uA
{{}}   CPU SRAM IDS : {{fuse_cpu_sram_ids_dig}},{{/([ ]+)/}}{{fuse_cpu_sram_ids_ana}} uA
{{}}   WARM IDS      : {{fuse_warm_ids_dig}},{{/([ ]+)/}}{{fuse_warm_ids_ana}} uA
{{}}   WARM SRAM IDS : {{fuse_warm_sram_ids_dig}},{{/([ ]+)/}}{{fuse_warm_sram_ids_ana}} uA
{{}}   SOC IDS      : {{fuse_soc_ids_dig}},{{/([ ]+)/}}{{fuse_soc_ids_ana}} uA
{{}}   SOC SRAM IDS : {{fuse_soc_sram_ids_dig}},{{/([ ]+)/}}{{fuse_soc_sram_ids_ana}} uA
{{}}   AON IDS      : {{fuse_aon_ids_dig}},{{/([ ]+)/}}{{fuse_aon_ids_ana}} uA
{{}}   AON SRAM IDS : {{fuse_aon_sram_ids_dig}},{{/([ ]+)/}}{{fuse_aon_sram_ids_ana}} uA
{{}}   DCS IDS    : {{fuse_dcs_ids_dig}},{{/([ ]+)/}}{{fuse_dcs_ids_ana}} uA
{{}}   ALLI IDS      : {{fuse_alli_ids_dig}},{{/([ ]+)/}}{{fuse_alli_ids_ana}} uA
{{}}
{{}} DVFM fuse settings
{{}}   Rev   : {{fuse_dvfm_rev_dig}}
{{}}   Base  : {{fuse_dvfm_base_dig}}, {{fuse_dvfm_base_ana}} uV
{{}}   MC001 : {{fuse_dvfm_mc001_dig}}, {{fuse_dvfm_mc001_ana}} uV
{{}}   MC002 : {{fuse_dvfm_mc002_dig}}, {{fuse_dvfm_mc002_ana}} uV
{{}}   MC003 : {{fuse_dvfm_mc003_dig}}, {{fuse_dvfm_mc003_ana}} uV
{{}}   MC004 : {{fuse_dvfm_mc004_dig}}, {{fuse_dvfm_mc004_ana}} uV
{{}}   MC005 : {{fuse_dvfm_mc005_dig}}, {{fuse_dvfm_mc005_ana}} uV
{{}}
{{}} SOC fuse settings
{{}}   MS001 : {{fuse_soc_ms001_dig}}, {{fuse_soc_ms001_ana}} uV
{{}}
{{}} SOC Warm fuse settings
{{}}   MW001 : {{fuse_soc_warm_mw001_dig}}, {{fuse_soc_warm_mw001_ana}} uV
{{}}   MW002 : {{fuse_soc_warm_mw002_dig}}, {{fuse_soc_warm_mw002_ana}} uV
{{}}   MW003 : {{fuse_soc_warm_mw003_dig}}, {{fuse_soc_warm_mw003_ana}} uV
{{}}
{{}} DCS fuse settings
{{}}   MD001 : {{fuse_dcs_md001_dig}}, {{fuse_dcs_md001_ana}} uV
{{}}   MD002 : {{fuse_dcs_md002_dig}}, {{fuse_dcs_md002_ana}} uV
{{}}   MD003 : {{fuse_dcs_md003_dig}}, {{fuse_dcs_md003_ana}} uV
{{}}
{{}} AON fuse settings
{{}}   MA001 : {{fuse_aon_ma001_dig}}, {{fuse_aon_ma001_ana}} uV
{{}}   MA002 : {{fuse_aon_ma002_dig}}, {{fuse_aon_ma002_ana}} uV
{{/([\s\S]*)/}}
{{}}SEP Security Fuse: {{fuse_sep_security}}
{{/([\s\S]*)/}}
PASS fuse config
```

ddr print info
----------
```
PASS ddr print info
```

pmgr vmode bin
----------
```
PASS pmgr vmode bin
```

pmu rails
----------
```
PASS pmu rails
```

os jitter 10
----------
```
PASS os jitter 10
```

therm toohot 100 7 100 7 7 1
----------
```
PASS therm toohot 100 7 100 7 7 1
```

therm thread resume
----------
```
PASS therm thread resume
```

therm sochot 120
----------
```
PASS therm sochot 120
```

ts reset auto
----------
```
PASS ts reset auto
```

mmu ddr-protect fsx
----------
```
PASS mmu ddr-protect fsx
```

slave up acc
----------
```
PASS slave up acc
```

acc dpeppt on
----------
```
PASS acc dpeppt on
```

sc heapchk on
----------
```
PASS sc heapchk on
```

oclamon teldvfm on
----------
```
PASS oclamon teldvfm on
```

oclamon scenario_tags on
----------
```
PASS oclamon scenario_tags on
```

acc nrg on
----------
```
PASS acc nrg on
```

slave up sio mar_sram.con alloc
----------
```
PASS slave up sio mar_sram.con alloc
```

telem config silence on
----------
```
PASS telem config silence on
```

telem config enable
----------
```
PASS telem config enable
```

switcher pattern ramp 290 -clk:p=2_6 -clk:w=3_5 -on
----------
```
PASS switcher pattern ramp 290 -clk:p=2_6 -clk:w=3_5 -on
```

therm sochot off
----------
```
PASS therm sochot off
```

therm thread pause
----------
```
PASS therm thread pause
```

telem test config 10 125 1 -analog-test-mode -check-stats
----------
```
PASS telem test config 10 125 1 -analog-test-mode -check-stats
```

telem test enable
----------
```
PASS telem test enable
```

sc run 26 50
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_26_50}} C SCtime={{sctime_sc_run_26_50}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 26 50
```

telem test disable
----------
```
PASS telem test disable
```

therm sochot on
----------
```
PASS therm sochot on
```

switcher off -reset
----------
```
PASS switcher off -reset
```

telem test config 10 125 250
----------
```
PASS telem test config 10 125 250
```

ts test config 10 125
----------
```
PASS ts test config 10 125
```

ts test enable
----------
```
PASS ts test enable
```

pmgr mode 0x0006255
----------
```
PASS pmgr mode 0x0006255
```

ddr margin test 0x363 80
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_ddr_margin_0x363_80}} C SCtime={{sctime_ddr_margin_0x363_80}} mSec{{}}
{{/([\s\S]*)/}}
PASS ddr margin test 0x363 80
```

ddr vref test 0x363 8 8 8 8
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_ddr_vref_test_0x363_8_8_8_8}} C SCtime={{sctime_ddr_vref_test_0x363_8_8_8_8}} mSec{{}}
{{/([\s\S]*)/}}
PASS ddr vref test 0x363 8 8 8 8
```

pmgr dvtm enable
----------
```
PASS pmgr dvtm enable
```

pmgr dvmr enable
----------
```
PASS pmgr dvmr enable
```

sc run 5
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_5}} C SCtime={{sctime_sc_run_5}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 5
```

bbq config fg 625 0 4 150 0 0 A
----------
```
PASS bbq config fg 625 0 4 150 0 0 A
```

bbq config 0x3 500 150 5 100 24 6 A
----------
```
PASS bbq config 0x3 500 150 5 100 24 6 A
```

bbq on
----------
```
PASS bbq on
```

sc run 6 5
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run__6_5}} C SCtime={{sctime_sc_run_6_5}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 6 5
```

sc run 13 10
------------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_13_10}} C SCtime={{sctime_sc_run_13_10}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 13 10
```

sc run 19 10
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_19_10}} C SCtime={{sctime_sc_run_19_10}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 19 10
```

sc run 27 10
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_27_10}} C SCtime={{sctime_sc_run_27_10}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 27 10
```

pmgr mode 0x0003255
----------
```
PASS pmgr mode 0x0003255
```

pmgr mode 0x0004255
----------
```
PASS pmgr mode 0x0004255
```

pmgr mode 0x0005255
----------
```
PASS pmgr mode 0x0005255
```

bbq config fg 625 0 4 150 0 0 B
----------
```
PASS bbq config fg 625 0 4 150 0 0 B
```

bbq config 0x3 500 150 5 100 24 6 B
----------
```
PASS bbq config 0x3 500 150 5 100 24 6 B
```

bbq off
----------
```
PASS bbq off
```

sc run 7
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_7}} C SCtime={{sctime_sc_run_7}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 7
```

switcher pattern random 10000 -jitter=250 -clk:p=4_6 -clk:w=4_5 -on
----------
```
PASS switcher pattern random 10000 -jitter=250 -clk:p=4_6 -clk:w=4_5 -on
```

sc run 13 100
-------------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_13_100}} C SCtime={{sctime_sc_run_13_100}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 13 100
```

sc run 19 100
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_19_100}} C SCtime={{sctime_sc_run_19_100}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 19 100
```

sc run 54
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_54}} C SCtime={{sctime_sc_run_54}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 54
```


ddr trefi soc
----------
```
PASS ddr trefi soc
```

ddr dcspg on
----------
```
PASS ddr dcspg on
```

sc run 56
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_56}} C SCtime={{sctime_sc_run_56}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 56
```

sc run 58
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_58}} C SCtime={{sctime_sc_run_58}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 58
```

mem cof 200
----------
```
PASS mem cof 200
```

mem vrb 2
----------
```
PASS mem vrb 2
```

switcher pattern rotary 2500000 -jitter=25000 -alt=500000 -clk:d=5_4_3 -on
----------
```
PASS switcher pattern rotary 2500000 -jitter=25000 -alt=500000 -clk:d=5_4_3 -on
```

sc run 674
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_674}} C SCtime={{sctime_sc_run_674}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 674
```

sc run 604
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_604}} C SCtime={{sctime_sc_run_604}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 604
```

sc run 63
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_63}} C SCtime={{sctime_sc_run_63}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 63
```

slave down sio
----------
```
PASS slave down sio
```

sc run 62
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_62}} C SCtime={{sctime_sc_run_62}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 62
```

sc run 761
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_761}} C SCtime={{sctime_sc_run_761}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 761
```

mem cof 0
----------
```
PASS mem cof 0
```

xfer con n15x_socstnd.cmd
----------
```
PASS xfer con
```

xfer con socstnd.cmd
----------
```
PASS xfer con
```

mmu ddr-linear
----------
```
PASS mmu ddr-linear
```

fs mount ddr
----------
```
PASS fs mount ddr
```

slave test 0x2D73 3
----------
```
PASS slave test 0x2D73 3
```

slave up ane mar_dram.shr alloc
----------
```
PASS slave up ane mar_dram.shr alloc
```

slave up aop mar_dram.shr alloc
----------
```
PASS slave up aop mar_dram.shr alloc
```

slave up rtp mar_dram.shr alloc
----------
```
PASS slave up rtp mar_dram.shr alloc
```

slave up sio mar_dram.shr alloc
----------
```
PASS slave up sio mar_dram.shr alloc
```

slave up smc mar_dram.shr alloc
----------
```
PASS slave up smc mar_dram.shr alloc
```

slave up ans mar_dram.shr alloc
----------
```
PASS slave up ans mar_dram.shr alloc
```

slave up sve kf_dram.con alloc
----------
```
PASS slave up sve kf_dram.con alloc
```

slave up gfx mar_dram.shr alloc
----------
```
PASS slave up gfx mar_dram.shr alloc
```

slave up disp mar_dram.shr alloc
----------
```
PASS slave up disp mar_dram.shr alloc
```

acc dpeppt reconfig
----------
```
PASS acc dpeppt reconfig
```

switcher pattern random 600 -jitter=579 -clk:p=2_3_4_5_6 -clk:w=3_4_5 -clk:d=3_4_5 -on -cpu=smc
----------
```
PASS switcher pattern random 600 -jitter=579 -clk:p=2_3_4_5_6 -clk:w=3_4_5 -clk:d=3_4_5 -on -cpu=smc
```

hammer -fmc 0x3E33 -urbm 0x3 -bonfire 0x3 -p -l 20 -t 5 -s 0x12ebb29e2b1f66d7
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_hammer_0x12ebb29e2b1f66d7}} C SCtime={{sctime_hammer_0x12ebb29e2b1f66d7}} mSec{{}}
{{/([\s\S]*)/}}
PASS hammer -fmc 0x3E33 -urbm 0x3 -bonfire 0x3 -p -l 20 -t 5 -s 0x12ebb29e2b1f66d7
```

sc run 61 2 -coremask 0x80
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_61_2_-coremask_0x80}} C SCtime={{sctime_stemp_sc_run_61_2_-coremask_0x80}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 61 2 -coremask 0x80
```

hammer -fmc 0x3E73 -urbm 0x3 -bonfire 0x3 -p -l 15 -t 5 -s 0xe0b7c15774cae105
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_hammer_0xe0b7c15774cae105}} C SCtime={{sctime_hammer_0xe0b7c15774cae105}} mSec{{}}
{{/([\s\S]*)/}}
PASS hammer -fmc 0x3E73 -urbm 0x3 -bonfire 0x3 -p -l 15 -t 5 -s 0xe0b7c15774cae105
```

sc run 61 8 -coremask 0x80
--------------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_61_8_coremask_0x80}} C SCtime={{sctime_sc_run_61_8_coremask_0x80}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 61 8 -coremask 0x80
```

sc run 8
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_8}} C SCtime={{sctime_sc_run_8}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 8
```

sc run 25 10 -coremask 0x80
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_25_10_coremask_0x80}} C SCtime={{sctime_sc_run_25_10_coremask_0x80}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 25 10 -coremask 0x80
```

sc run 40 5
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_40_5}} C SCtime={{sctime_sc_run_40_5}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 40 5
```

sc run 35
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_35}} C SCtime={{sctime_sc_run_35}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 35
```

slave down disp
----------
```
PASS slave down disp
```

ans fw-init
----------
```
PASS ans fw-init
```

pmgr mode 0x0006235
----------
```
PASS pmgr mode 0x0006235
```

sc run 24
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_24}} C SCtime={{sctime_sc_run_24}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 24
```

sc run 83
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_83}} C SCtime={{sctime_sc_run_83}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 83
```

sc run 84
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_84}} C SCtime={{sctime_sc_run_84}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 84
```

sc run 100
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_100}} C SCtime={{sctime_sc_run_100}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 100
```

sc run 136
----------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_136}} C SCtime={{sctime_sc_run_136}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 136
```

sc run 146
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_146}} C SCtime={{sctime_sc_run_146}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 146
```

pmgr mode 0x0006245
----------
```
PASS pmgr mode 0x0006245
```

ans free-heap
----------
```
PASS ans free-heap
```

slave down gfx
----------
```
PASS slave down gfx
```

switcher pattern random 10000 -jitter=2000 -clk:w=3_4_5 -on -cpu=smc
----------
```
PASS switcher pattern random 10000 -jitter=2000 -clk:w=3_4_5 -on -cpu=smc
```

sc run 46
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_46}} C SCtime={{sctime_sc_run_46}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 46
```

sc run 46 2
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_46_2}} C SCtime={{sctime_sc_run_46_2}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 46 2
```

pmgr mode 0x0006155
----------
```
PASS pmgr mode 0x0006155
```

sc run 50
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_50}} C SCtime={{sctime_sc_run_50}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 50
```

sc run 11
---------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_11}} C SCtime={{sctime_sc_run_11}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 11
```

fs ck -A -d -v
----------
```
PASS fs ck -A -d -v
```

sc run 61 4 -coremask 0x80
--------------
```
{{}}TEST_RESULT_B{{}}Stemp={{stemp_sc_run_61_4_coremask_0x80}} C SCtime={{sctime_sc_run_61_4_coremask_0x80}} mSec{{}}
{{/([\s\S]*)/}}
PASS sc run 61 4 -coremask 0x80
```
Future commands to be parsed
----------------------------
