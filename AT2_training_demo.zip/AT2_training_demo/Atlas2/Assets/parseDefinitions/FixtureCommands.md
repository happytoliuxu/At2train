 EFI parsing definition file
===========================

Version Info
------------
07/22/2020 ver 0.1

[TOC]

Commands that can be parsed
===========================

GET FW VER
--------
```
FW VER={{FixtureFWVersion}}
```

GET HW VER
--------
```
HW VER={{FixtureHWVersion}}
```

GET BASE FLOOR NUM
--------
```
Position_Num={{headID}}
Floor_Num={{}}
```

GET TRAY SN
--------
```
TRAY SN BP {{fixtureID}}
```

GET BATT VOLTAGE
--------
```
BATT VOLTAGE {{battVol}}mV
```

GET PP_VDD_MAIN ADC
--------
```
VDD_MAIN = {{VDD_MAIN}}mV
```

GET DFU STATUS_1
--------
```
{{dfuStatusVol}}V
```

Future commands to be parsed
----------------------------
