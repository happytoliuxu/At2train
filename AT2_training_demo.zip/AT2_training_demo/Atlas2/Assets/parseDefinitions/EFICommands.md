 EFI parsing definition file
===========================

Version Info
------------
07/22/2020 ver 0.1

[TOC]

Commands that can be parsed
===========================

syscfg print MLB#
--------
```
{{/([\s\S]*)/}}
{{MLB_Num}}
{{}}
```

syscfg print MLB# from iboot
--------
 - Command name: `syscfg print MLB# from iboot`
 - Command to send: `syscfg print MLB#`
```

{{serialnumberFromiBoot}}
```
syscfg print CFG#
--------
```
{{dutCFG}}
{{}}
```

build-revision type
--------
```
{{build-revision type}}
```

nvram --get boot-args
--------
 - Command name: `nvram --get boot-args`
 - Command to send: `nvram --get boot-args`
```
boot-args = {{boot_args}}
{{}}
```

soc -p
--------
```
{{/([\s\S]*)/}}
{{}}fuse-rev: {{fuse_rev}}
{{/([\s\S]*)/}}
{{}}revision: {{soc_rev}}
{{}}
```

version
-------
```
{{/([\s\S]*)/}}
{{diags_program}} Diagnostics
Branch ({{diags_branch}}), Commit ({{diags_commit}}), Platform ({{diags_platform}})
{{/([\s\S]*)/}}
	Built by - {{diags_built_by}}
	Built at - {{diags_built_at}}
	Version  - {{efidiags_version}}
{{/([\s\S]*)/}}
Subcomponents:
	APFS - Version: {{apfs_version}}  Commit ({{apfs_commit}})
	ANS2 - Version: {{ans2_version}}
{{/([\s\S]*)/}}
```

pmuadc --read all
---------
```
PMU ADC test
Read all Channels
Read PMU ADC channels
vddout: {{vddout}} mV
vbat: {{vbat}} mV
vssa: {{vssa}} mV
vboost: {{vboost}} mV
vaux_sw: {{vaux_sw}} mV
pmux_out: {{pmux_out}} mV
die_temp: {{die_temp}} C
tcal: {{tcal}} mV
tbat: {{tbat}} Ohm
temp1: {{temp1}} Ohm
temp2: {{temp2}} Ohm
temp3: {{temp3}} Ohm
temp4: {{temp4}} Ohm
temp5: {{temp5}} Ohm
temp_ldo4: {{temp_ldo4}} C
temp_ldo13: {{temp_ldo13}} C
temp_ldo14: {{temp_ldo14}} C
temp_ldo15: {{temp_ldo15}} C
temp_chg: {{temp_chg}} C
temp_buck0: {{temp_buck0}} C
temp_buck1: {{temp_buck1}} C
temp_buck2: {{temp_buck2}} C
temp_buck3: {{temp_buck3}} C
temp_buck4: {{temp_buck4}} C
temp_buck5: {{temp_buck5}} C
temp_buck6: {{temp_buck6}} C
temp_buck7: {{temp_buck7}} C
temp_buck8: {{temp_buck8}} C
temp_buck9: {{temp_buck9}} C
temp_buck10: {{temp_buck10}} C
temp_buck11: {{temp_buck11}} C
temp_bubo: {{temp_bubo}} C
tjint: {{tjint}} C
temp_boost: {{temp_boost}} C
temp_sw4: {{temp_sw4}} C
temp_sw6: {{temp_sw6}} C
temp_sw21: {{temp_sw21}} C
temp_aux_sw: {{temp_aux_sw}} C
ibuck0: {{ibuck0}} mA
ibuck1: {{ibuck1}} mA
ibuck2: {{ibuck2}} mA
ibuck3: {{ibuck3}} mA
ibuck4: {{ibuck4}} mA
ibuck5: {{ibuck5}} mA
ibuck6: {{ibuck6}} mA
ibuck7: {{ibuck7}} mA
ibuck8: {{ibuck8}} mA
ibuck9: {{ibuck9}} mA
ibuck10: {{ibuck10}} mA
ibuck11: {{ibuck11}} mA
ibuck0_offset: {{ibuck0_offset}} mA
ibuck1_offset: {{ibuck1_offset}} mA
ibuck2_offset: {{ibuck2_offset}} mA
ibuck3_offset: {{ibuck3_offset}} mA
ibuck4_offset: {{ibuck4_offset}} mA
ibuck5_offset: {{ibuck5_offset}} mA
ibuck6_offset: {{ibuck6_offset}} mA
ibuck7_offset: {{ibuck7_offset}} mA
ibuck8_offset: {{ibuck8_offset}} mA
ibuck9_offset: {{ibuck9_offset}} mA
ibuck10_offset: {{ibuck10_offset}} mA
ibuck11_offset: {{ibuck11_offset}} mA
vref_1v2: {{vref_1v2}} mV
ichg_0mA_IMAX: {{ichg_0mA_IMAX}} mA
ichg_0mA_50mA: {{ichg_0mA_50mA}} mA
ildo_11_eq: {{ildo_11_eq}} mA
ildo_12_eq: {{ildo_12_eq}} mA
ildo_14_eq: {{ildo_14_eq}} mA
ildo_15_eq: {{ildo_15_eq}} mA
BIST buck0: {{buck0}} mV
BIST buck1: {{buck1}} mV
BIST buck2: {{buck2}} mV
BIST buck3: {{buck3}} mV
BIST buck4: {{buck4}} mV
BIST buck5: {{buck5}} mV
BIST buck6: {{buck6}} mV
BIST buck7: {{buck7}} mV
BIST buck8: {{buck8}} mV
BIST buck9: {{buck9}} mV
BIST buck10: {{buck10}} mV
BIST buck11: {{buck11}} mV
BIST bubo: {{bubo}} mV
BIST vdropout_ibubo: {{vdropout_ibubo}} mV
BIST vdropout_ibubo_offset: {{vdropout_ibubo_offset}} mV
BIST dropout_sw2a: {{dropout_sw2a}} mV
BIST dropout_sw2a_offset: {{dropout_sw2a_offset}} mV
BIST dropout_sw2b: {{dropout_sw2b}} mV
BIST dropout_sw2b_offset: {{dropout_sw2b_offset}} mV
BIST dropout_sw2c: {{dropout_sw2c}} mV
BIST dropout_sw2c_offset: {{dropout_sw2c_offset}} mV
BIST dropout_sw3a: {{dropout_sw3a}} mV
BIST dropout_sw3a_offset: {{dropout_sw3a_offset}} mV
BIST dropout_sw3b: {{dropout_sw3b}} mV
BIST dropout_sw3b_offset: {{dropout_sw3b_offset}} mV
BIST dropout_sw3c: {{dropout_sw3c}} mV
BIST dropout_sw3c_offset: {{dropout_sw3c_offset}} mV
BIST dropout_sw3d: {{dropout_sw3d}} mV
BIST dropout_sw3d_offset: {{dropout_sw3d_offset}} mV
BIST dropout_sw3e: {{dropout_sw3e}} mV
BIST dropout_sw3e_offset: {{dropout_sw3e_offset}} mV
BIST dropout_sw4: {{dropout_sw4}} mV
BIST dropout_sw4_offset: {{dropout_sw4_offset}} mV
BIST dropout_sw6: {{dropout_sw6}} mV
BIST dropout_sw6_offset: {{dropout_sw6_offset}} mV
BIST dropout_sw8a: {{dropout_sw8a}} mV
BIST dropout_sw8a_offset: {{dropout_sw8a_offset}} mV
BIST dropout_sw8b: {{dropout_sw8b}} mV
BIST dropout_sw8b_offset: {{dropout_sw8b_offset}} mV
BIST dropout_sw11a: {{dropout_sw11a}} mV
BIST dropout_sw11a_offset: {{dropout_sw11a_offset}} mV
BIST dropout_sw11b: {{dropout_sw11b}} mV
BIST dropout_sw11b_offset: {{dropout_sw11b_offset}} mV
BIST dropout_sw11c: {{dropout_sw11c}} mV
BIST dropout_sw11c_offset: {{dropout_sw11c_offset}} mV
BIST dropout_sw18: {{dropout_sw18}} mV
BIST dropout_sw18_offset: {{dropout_sw18_offset}} mV
BIST dropout_sw19: {{dropout_sw19}} mV
BIST dropout_sw19_offset: {{dropout_sw19_offset}} mV
BIST dropout_sw20: {{dropout_sw20}} mV
BIST dropout_sw20_offset: {{dropout_sw20_offset}} mV
BIST dropout_sw21: {{dropout_sw21}} mV
BIST dropout_sw21_offset: {{dropout_sw21_offset}} mV
BIST dropout_sw_vaux: {{dropout_sw_vaux}} mV
BIST dropout_sw_vaux_offset: {{dropout_sw_vaux_offset}} mV
BIST dropout_vpmux_out: {{dropout_vpmux_out}} mV
BIST dropout_vpmux_out_offset: {{dropout_vpmux_out_offset}} mV
BIST sw2a: {{sw2a}} mV
BIST sw2b: {{sw2b}} mV
BIST sw2c: {{sw2c}} mV
BIST sw3a: {{sw3a}} mV
BIST sw3b: {{sw3b}} mV
BIST sw3c: {{sw3c}} mV
BIST sw3d: {{sw3d}} mV
BIST sw3e: {{sw3e}} mV
BIST sw4: {{sw4}} mV
BIST sw6: {{sw6}} mV
BIST sw8a: {{sw8a}} mV
BIST sw8b: {{sw8b}} mV
BIST sw11a: {{sw11a}} mV
BIST sw11b: {{sw11b}} mV
BIST sw11c: {{sw11c}} mV
BIST sw18: {{sw18}} mV
BIST sw19: {{sw19}} mV
BIST sw20: {{sw20}} mV
BIST sw21: {{sw21}} mV
BIST ldo1: {{ldo1}} mV
BIST ldo2: {{ldo2}} mV
BIST ldo3: {{ldo3}} mV
BIST ldo4: {{ldo4}} mV
BIST ldo5: {{ldo5}} mV
BIST ldo6: {{ldo6}} mV
BIST ldo7: {{ldo7}} mV
BIST ldo8: {{ldo8}} mV
BIST ldo9: {{ldo9}} mV
BIST ldo11: {{ldo11}} mV
BIST ldo12: {{ldo12}} mV
BIST ldo13: {{ldo13}} mV
BIST ldo14: {{ldo14}} mV
BIST ldo15: {{ldo15}} mV
BIST ldo16: {{ldo16}} mV
BIST ldo17: {{ldo17}} mV
BIST vrtc: {{vrtc}} mV
BIST chg_hr: {{chg_hr}} mV
BIST chg_hr_off: {{chg_hr_off}} mV
BIST ildo1: {{ildo1}} mA
BIST ildo2: {{ildo2}} mA
BIST ildo3: {{ildo3}} mA
BIST ildo4: {{ildo4}} mA
BIST ildo5: {{ildo5}} mA
BIST ildo6: {{ildo6}} mA
BIST ildo7: {{ildo7}} mA
BIST ildo8: {{ildo8}} mA
BIST ildo9: {{ildo9}} mA
BIST ildo13: {{ildo13}} mA
BIST ildo16: {{ildo16}} mA
BIST ildo17: {{ildo17}} mA
BIST irtc: {{irtc}} mA
BIST iboost: {{iboost}} mA
BIST appmux: {{appmux}} mV
BIST appmux_in1: {{appmux_in1}} mV
BIST appmux_in2: {{appmux_in2}} mV
BIST appmux_in3: {{appmux_in3}} mV
BIST appmux_in4: {{appmux_in4}} mV
BIST appmux_in5: {{appmux_in5}} mV
BIST appmux_in6: {{appmux_in6}} mV
BIST appmux_in7: {{appmux_in7}} mV
BIST appmux_sw2: {{appmux_sw2}} mV
BIST appmux_sw3: {{appmux_sw3}} mV
BIST appmux_sw4: {{appmux_sw4}} mV
BIST appmux_sw6: {{appmux_sw6}} mV
BIST appmux_sw8: {{appmux_sw8}} mV
BIST appmux_sw11: {{appmux_sw11}} mV
BIST appmux_aux_sw_out: {{appmux_aux_sw_out}} mV
BIST appmux_vbuck0: {{appmux_vbuck0}} mV
BIST appmux_vbuck1: {{appmux_vbuck1}} mV
BIST appmux_vbuck4: {{appmux_vbuck4}} mV
BIST appmux_vbuck5: {{appmux_vbuck5}} mV
BIST appmux_vbuck6: {{appmux_vbuck6}} mV
BIST appmux_vbuck7: {{appmux_vbuck7}} mV
BIST appmux_vbuck9: {{appmux_vbuck9}} mV
BIST appmux_vbuck10: {{appmux_vbuck10}} mV
BIST appmux_vldo1: {{appmux_vldo1}} mV
BIST appmux_vldo2: {{appmux_vldo2}} mV
BIST appmux_vldo3: {{appmux_vldo3}} mV
BIST appmux_vldo4: {{appmux_vldo4}} mV
BIST appmux_vldo5: {{appmux_vldo5}} mV
BIST appmux_vldo6: {{appmux_vldo6}} mV
BIST appmux_vldo7: {{appmux_vldo7}} mV
BIST appmux_vldo8: {{appmux_vldo8}} mV
BIST appmux_vldo9: {{appmux_vldo9}} mV
BIST appmux_vldo11: {{appmux_vldo11}} mV
BIST appmux_vldo12: {{appmux_vldo12}} mV
BIST appmux_vldo13: {{appmux_vldo13}} mV
BIST appmux_vldo14: {{appmux_vldo14}} mV
BIST appmux_vldo15: {{appmux_vldo15}} mV
BIST appmux_vldo16: {{appmux_vldo16}} mV
BIST appmux_vldo17: {{appmux_vldo17}} mV
BIST appmux_sw2a_out: {{appmux_sw2a_out}} mV
BIST appmux_sw2b_out: {{appmux_sw2b_out}} mV
BIST appmux_sw2c_out: {{appmux_sw2c_out}} mV
BIST appmux_sw3a_out: {{appmux_sw3a_out}} mV
BIST appmux_sw3b_out: {{appmux_sw3b_out}} mV
BIST appmux_sw3c_out: {{appmux_sw3c_out}} mV
BIST appmux_sw3d_out: {{appmux_sw3d_out}} mV
BIST appmux_sw3e_out: {{appmux_sw3e_out}} mV
BIST appmux_sw4_out: {{appmux_sw4_out}} mV
BIST appmux_sw6_out: {{appmux_sw6_out}} mV
BIST appmux_sw8a_out: {{appmux_sw8a_out}} mV
BIST appmux_sw8b_out: {{appmux_sw8b_out}} mV
BIST appmux_sw11a_out: {{appmux_sw11a_out}} mV
BIST appmux_sw11b_out: {{appmux_sw11b_out}} mV
BIST appmux_sw11c_out: {{appmux_sw11c_out}} mV
BIST appmux_sw18_out: {{appmux_sw18_out}} mV
BIST appmux_sw19_out: {{appmux_sw19_out}} mV
BIST appmux_sw20_out: {{appmux_sw20_out}} mV
BIST appmux_sw21_out: {{appmux_sw21_out}} mV
BIST appmux_pmux_out: {{appmux_pmux_out}} mV
BIST appmux_gpio1: {{appmux_gpio1}} mV
BIST appmux_gpio2: {{appmux_gpio2}} mV
BIST appmux_gpio3: {{appmux_gpio3}} mV
BIST appmux_gpio4: {{appmux_gpio4}} mV
BIST appmux_gpio5: {{appmux_gpio5}} mV
BIST appmux_gpio6: {{appmux_gpio6}} mV
BIST appmux_gpio7: {{appmux_gpio7}} mV
BIST appmux_gpio8: {{appmux_gpio8}} mV
BIST appmux_gpio9: {{appmux_gpio9}} mV
BIST appmux_gpio10: {{appmux_gpio10}} mV
BIST appmux_gpio11: {{appmux_gpio11}} mV
BIST appmux_gpio12: {{appmux_gpio12}} mV
BIST appmux_gpio13: {{appmux_gpio13}} mV
BIST appmux_gpio14: {{appmux_gpio14}} mV
BIST appmux_gpio15: {{appmux_gpio15}} mV
BIST appmux_gpio16: {{appmux_gpio16}} mV
BIST appmux_gpio17: {{appmux_gpio17}} mV
BIST appmux_gpio18: {{appmux_gpio18}} mV
BIST appmux_gpio19: {{appmux_gpio19}} mV
BIST appmux_gpio20: {{appmux_gpio20}} mV
BIST appmux_gpio21: {{appmux_gpio21}} mV
BIST appmux_gpio22: {{appmux_gpio22}} mV
BIST appmux_gpio23: {{appmux_gpio23}} mV
BIST appmux_gpio24: {{appmux_gpio24}} mV
BIST appmux_gpio25: {{appmux_gpio25}} mV
BIST appmux_gpio26: {{appmux_gpio26}} mV
BIST appmux_gpio27: {{appmux_gpio27}} mV
BIST appmux_gpio28: {{appmux_gpio28}} mV
BIST appmux_gpio29: {{appmux_gpio29}} mV
BIST appmux_gpio30: {{appmux_gpio30}} mV
BIST appmux_gpio32: {{appmux_gpio32}} mV
BIST appmux_gpio33: {{appmux_gpio33}} mV
BIST appmux_gpio34: {{appmux_gpio34}} mV
BIST appmux_gpio35: {{appmux_gpio35}} mV
BIST appmux_gpio36: {{appmux_gpio36}} mV
BIST appmux_gpio38: {{appmux_gpio38}} mV
BIST appmux_gpio39: {{appmux_gpio39}} mV
BIST appmux_gpio40: {{appmux_gpio40}} mV
BIST appmux_gpio41: {{appmux_gpio41}} mV
BIST appmux_gpio42: {{appmux_gpio42}} mV
BIST appmux_gpio43: {{appmux_gpio43}} mV
BIST appmux_gpio44: {{appmux_gpio44}} mV
BIST appmux_gpio45: {{appmux_gpio45}} mV
BIST appmux_gpio46: {{appmux_gpio46}} mV
BIST appmux_gpio47: {{appmux_gpio47}} mV
BIST appmux_gpio48: {{appmux_gpio48}} mV
```

wifi --send_cmd ver
--------
```
{{/([\s\S]*)/}}
{{}}firmware{{/[ ]+/}}[{{wifi_MAC}}]
{{}}phy{{/[ ]+/}}[{{wifi_Phy}}]
OK
```

bluetooth --send_cmd ver
--------
```
BT MAC FW{{/[ ]+/}}{{BT_MAC}}
BT PHY FW{{/[ ]+/}}{{BT_Phy}}
{{/([\s\S]*)/}}
OK
```

sensor -l
--------
```
Name: accel
Description: {{accel_vendor}} {{accel_part}} Accelerometer ({{accel_chip}})
Installed: yes

Name: gyro
Description: {{gyro_vendor}} {{gyro_part}} Gyro ({{gyro_chip}})
Installed: yes
```

sensor -s gyro --exectest drive_freq_measurement
--------
```
clk_pos_p = {{clk_pos_p}} Khz
clk_vel_p = {{clk_vel_p}} Khz
```

sensor --sel accel --exectest selftest_manual
--------
```
Capturing {{accel_self_test_sample_count}} samples in normal mode (ACC0)...
norm-mode: x = {{accel_self_test_normal_x}}, y = {{accel_self_test_normal_y}}, z = {{accel_self_test_normal_z}}

Capturing {{accel_self_test_sample_count_pos}} samples with positive excitation (ACC1)...
pos-mode: x = {{accel_self_test_pos_output_x}}, y = {{accel_self_test_pos_output_y}}, z = {{accel_self_test_pos_output_z}}
pos-response: x = {{accel_self_test_pos_x}}, y = {{accel_self_test_pos_y}}, z = {{accel_self_test_pos_z}}
limits: {{accel_self_test_pos_lsl_x}} <= X <= {{accel_self_test_pos_usl_x}}, {{accel_self_test_pos_lsl_y}} <= Y <= {{accel_self_test_pos_usl_y}}, {{accel_self_test_pos_lsl_z}} <= Z <= {{accel_self_test_pos_usl_z}}
pos-result: {{accel_self_test_pos_result}}

Capturing {{accel_self_test_sample_count_neg}} samples with negative excitation (ACC2)...
neg-mode: x = {{accel_self_test_neg_output_x}}, y = {{accel_self_test_neg_output_y}}, z = {{accel_self_test_neg_output_z}}
neg-response: x = {{accel_self_test_neg_x}}, y = {{accel_self_test_neg_y}}, z = {{accel_self_test_neg_z}}
limits: {{accel_self_test_neg_lsl_x}} <= X <= {{accel_self_test_neg_usl_x}}, {{accel_self_test_neg_lsl_y}} <= Y <= {{accel_self_test_neg_usl_y}}, {{accel_self_test_neg_lsl_z}} <= Z <= {{accel_self_test_neg_usl_z}}
neg-result: {{accel_self_test_neg_result}}

SymErr-response: x = {{accel_self_test_symerr_x}}, y = {{accel_self_test_symerr_y}}, z = {{accel_self_test_symerr_z}}
limits: {{accel_self_test_symerr_lsl_x}} <= X <= {{accel_self_test_symerr_usl_x}}, {{accel_self_test_symerr_lsl_y}} <= Y <= {{accel_self_test_symerr_usl_y}}, {{accel_self_test_symerr_lsl_z}} <= Z <= {{accel_self_test_symerr_usl_z}}
SymErr-result: {{accel_self_test_symerr_result}}
test-result: {{accel_self_test_result}}
PASS
```

ramlog --dump; echo baseband_power
---------
```
{{/([\s\S]*)/}}
{{}}|fl(15)...{{}} {{baseband_power}} {{}}|
```

bblib -e 'FCT_LPEM_CHECK(msg)'
--------
```
{{/([\s\S]*)/}}
alisha_lpem : {{alisha_lpem}}
```

smokeyshell -e "FCT_CHECK('UWB_DFU',res)"
--------
```
uwbdfu : {{uwbdfu_result}}
uwbdfu.uwb : {{uwb_result}}
uwbdfu.uwb.uwbon : {{uwbon_result}}
uwbdfu.uwb.uwbloadfw : {{uwbloadfw_result}}
uwbdfu.uwb.uwbreportvars : {{uwbreportvars_result}}
uwbdfu.uwb.uwbping : {{uwbping_result}}
uwbdfu.uwb.uwbcheckgpios : {{uwbcheckgpios_result}}
uwbdfu.uwb.uwbspilb : {{uwbspilb_result}}
uwbdfu.uwb.uwbhostwake : {{uwbhostwake_result}}
uwbdfu.ds : {{ds_result}}
uwbdfu.ds.dsuwb : {{dsuwb_result}}
uwbdfu.cleanup : {{cleanup_result}}
```

smokeyshell -e "FCT_CHECK('BB_SMTQT',res)"
--------
```
bbsmtqt : {{bbsmtqt_result}}
bbsmtqt.baseband : {{baseband_result}}
bbsmtqt.baseband.bbon : {{bbon_result}}
bbsmtqt.baseband.bbloadfw : {{bbloadfw_result}}
bbsmtqt.baseband.bbcheckcalibration : {{bbcheckcalibration_result}}
bbsmtqt.baseband.bbsim : {{bbsim_result}}
bbsmtqt.baseband.gpson : {{gpson_result}}
bbsmtqt.baseband.gpsloadfw : {{gpsloadfw_result}}
bbsmtqt.wlan : {{wlan_result}}
bbsmtqt.wlan.wlon : {{wlon_result}}
bbsmtqt.wlan.wlloadfw : {{wlloadfw_result}}
bbsmtqt.wlan.wlotp : {{wlotp_result}}
bbsmtqt.wlan.wlds : {{wlds_result}}
bbsmtqt.wlan.wluart : {{wluart_result}}
bbsmtqt.sh : {{sh_result}}
bbsmtqt.sh.selectnfcp : {{selectnfcp_result}}
bbsmtqt.sh.shon : {{shon_result}}
bbsmtqt.sh.shseping : {{shseping_result}}
bbsmtqt.sh.shswp : {{shswp_result}}
bbsmtqt.sh.se : {{se_result}}
bbsmtqt.sh.se.selb : {{selb_result}}
bbsmtqt.sh.se.selb_alysha_uwb_inwallet : {{selb_alysha_uwb_inwallet_result}}
bbsmtqt.sh.sepostdumpaclog : {{sepostdumpaclog_result}}
bbsmtqt.sh.shscleanup : {{shscleanup_result}}
bbsmtqt.uwb : {{uwb_result}}
bbsmtqt.uwb.uwbloadfw : {{uwbloadfw_result}}
```

baseband -p
--------
```
firmware-version: "{{BBFWVER}}"
{{/([\s\S]*)/}}
{{}}sn: "{{BBSNUM}}"
```

baseband --on
--------
```
{{}}
OK
```

baseband --load_firmware
--------
```
{{}}
OK
```

syscfg print WSKU
--------
```
{{}}0x{{WSKU1}} 0x{{WSKU2}} 0x{{WSKU3}} 0x{{WSKU4}}
```

pmuadc --read all --avg 25
---------
 - Command name : `pmuadc --read all --avg 25`
 - Command to send: `pmuadc --read all --avg 25`
```
PMU ADC test
Read all Channels
Read PMU ADC channels
vddout: {{vddout}} mV
vbat: {{vbat}} mV
vssa: {{vssa}} mV
vboost: {{vboost}} mV
vaux_sw: {{vaux_sw}} mV
pmux_out: {{pmux_out}} mV
die_temp: {{die_temp}} C
tcal: {{tcal}} mV
tbat: {{tbat}} Ohm
temp1: {{temp1}} Ohm
temp2: {{temp2}} Ohm
temp3: {{temp3}} Ohm
temp4: {{temp4}} Ohm
temp5: {{temp5}} Ohm
temp_ldo4: {{temp_ldo4}} C
temp_ldo13: {{temp_ldo13}} C
temp_ldo14: {{temp_ldo14}} C
temp_ldo15: {{temp_ldo15}} C
temp_chg: {{temp_chg}} C
temp_buck0: {{temp_buck0}} C
temp_buck1: {{temp_buck1}} C
temp_buck2: {{temp_buck2}} C
temp_buck3: {{temp_buck3}} C
temp_buck4: {{temp_buck4}} C
temp_buck5: {{temp_buck5}} C
temp_buck6: {{temp_buck6}} C
temp_buck7: {{temp_buck7}} C
temp_buck8: {{temp_buck8}} C
temp_buck9: {{temp_buck9}} C
temp_buck10: {{temp_buck10}} C
temp_buck11: {{temp_buck11}} C
temp_bubo: {{temp_bubo}} C
tjint: {{tjint}} C
temp_boost: {{temp_boost}} C
temp_sw4: {{temp_sw4}} C
temp_sw6: {{temp_sw6}} C
temp_sw21: {{temp_sw21}} C
temp_aux_sw: {{temp_aux_sw}} C
ibuck0: {{ibuck0}} mA
ibuck1: {{ibuck1}} mA
ibuck2: {{ibuck2}} mA
ibuck3: {{ibuck3}} mA
ibuck4: {{ibuck4}} mA
ibuck5: {{ibuck5}} mA
ibuck6: {{ibuck6}} mA
ibuck7: {{ibuck7}} mA
ibuck8: {{ibuck8}} mA
ibuck9: {{ibuck9}} mA
ibuck10: {{ibuck10}} mA
ibuck11: {{ibuck11}} mA
ibuck0_offset: {{ibuck0_offset}} mA
ibuck1_offset: {{ibuck1_offset}} mA
ibuck2_offset: {{ibuck2_offset}} mA
ibuck3_offset: {{ibuck3_offset}} mA
ibuck4_offset: {{ibuck4_offset}} mA
ibuck5_offset: {{ibuck5_offset}} mA
ibuck6_offset: {{ibuck6_offset}} mA
ibuck7_offset: {{ibuck7_offset}} mA
ibuck8_offset: {{ibuck8_offset}} mA
ibuck9_offset: {{ibuck9_offset}} mA
ibuck10_offset: {{ibuck10_offset}} mA
ibuck11_offset: {{ibuck11_offset}} mA
vref_1v2: {{vref_1v2}} mV
ichg_0mA_IMAX: {{ichg_0mA_IMAX}} mA
ichg_0mA_50mA: {{ichg_0mA_50mA}} mA
ildo_11_eq: {{ildo_11_eq}} mA
ildo_12_eq: {{ildo_12_eq}} mA
ildo_14_eq: {{ildo_14_eq}} mA
ildo_15_eq: {{ildo_15_eq}} mA
BIST buck0: {{buck0}} mV
BIST buck1: {{buck1}} mV
BIST buck2: {{buck2}} mV
BIST buck3: {{buck3}} mV
BIST buck4: {{buck4}} mV
BIST buck5: {{buck5}} mV
BIST buck6: {{buck6}} mV
BIST buck7: {{buck7}} mV
BIST buck8: {{buck8}} mV
BIST buck9: {{buck9}} mV
BIST buck10: {{buck10}} mV
BIST buck11: {{buck11}} mV
BIST bubo: {{bubo}} mV
BIST vdropout_ibubo: {{vdropout_ibubo}} mV
BIST vdropout_ibubo_offset: {{vdropout_ibubo_offset}} mV
BIST dropout_sw2a: {{dropout_sw2a}} mV
BIST dropout_sw2a_offset: {{dropout_sw2a_offset}} mV
BIST dropout_sw2b: {{dropout_sw2b}} mV
BIST dropout_sw2b_offset: {{dropout_sw2b_offset}} mV
BIST dropout_sw2c: {{dropout_sw2c}} mV
BIST dropout_sw2c_offset: {{dropout_sw2c_offset}} mV
BIST dropout_sw3a: {{dropout_sw3a}} mV
BIST dropout_sw3a_offset: {{dropout_sw3a_offset}} mV
BIST dropout_sw3b: {{dropout_sw3b}} mV
BIST dropout_sw3b_offset: {{dropout_sw3b_offset}} mV
BIST dropout_sw3c: {{dropout_sw3c}} mV
BIST dropout_sw3c_offset: {{dropout_sw3c_offset}} mV
BIST dropout_sw3d: {{dropout_sw3d}} mV
BIST dropout_sw3d_offset: {{dropout_sw3d_offset}} mV
BIST dropout_sw3e: {{dropout_sw3e}} mV
BIST dropout_sw3e_offset: {{dropout_sw3e_offset}} mV
BIST dropout_sw4: {{dropout_sw4}} mV
BIST dropout_sw4_offset: {{dropout_sw4_offset}} mV
BIST dropout_sw6: {{dropout_sw6}} mV
BIST dropout_sw6_offset: {{dropout_sw6_offset}} mV
BIST dropout_sw8a: {{dropout_sw8a}} mV
BIST dropout_sw8a_offset: {{dropout_sw8a_offset}} mV
BIST dropout_sw8b: {{dropout_sw8b}} mV
BIST dropout_sw8b_offset: {{dropout_sw8b_offset}} mV
BIST dropout_sw11a: {{dropout_sw11a}} mV
BIST dropout_sw11a_offset: {{dropout_sw11a_offset}} mV
BIST dropout_sw11b: {{dropout_sw11b}} mV
BIST dropout_sw11b_offset: {{dropout_sw11b_offset}} mV
BIST dropout_sw11c: {{dropout_sw11c}} mV
BIST dropout_sw11c_offset: {{dropout_sw11c_offset}} mV
BIST dropout_sw18: {{dropout_sw18}} mV
BIST dropout_sw18_offset: {{dropout_sw18_offset}} mV
BIST dropout_sw19: {{dropout_sw19}} mV
BIST dropout_sw19_offset: {{dropout_sw19_offset}} mV
BIST dropout_sw20: {{dropout_sw20}} mV
BIST dropout_sw20_offset: {{dropout_sw20_offset}} mV
BIST dropout_sw21: {{dropout_sw21}} mV
BIST dropout_sw21_offset: {{dropout_sw21_offset}} mV
BIST dropout_sw_vaux: {{dropout_sw_vaux}} mV
BIST dropout_sw_vaux_offset: {{dropout_sw_vaux_offset}} mV
BIST dropout_vpmux_out: {{dropout_vpmux_out}} mV
BIST dropout_vpmux_out_offset: {{dropout_vpmux_out_offset}} mV
BIST sw2a: {{sw2a}} mV
BIST sw2b: {{sw2b}} mV
BIST sw2c: {{sw2c}} mV
BIST sw3a: {{sw3a}} mV
BIST sw3b: {{sw3b}} mV
BIST sw3c: {{sw3c}} mV
BIST sw3d: {{sw3d}} mV
BIST sw3e: {{sw3e}} mV
BIST sw4: {{sw4}} mV
BIST sw6: {{sw6}} mV
BIST sw8a: {{sw8a}} mV
BIST sw8b: {{sw8b}} mV
BIST sw11a: {{sw11a}} mV
BIST sw11b: {{sw11b}} mV
BIST sw11c: {{sw11c}} mV
BIST sw18: {{sw18}} mV
BIST sw19: {{sw19}} mV
BIST sw20: {{sw20}} mV
BIST sw21: {{sw21}} mV
BIST ldo1: {{ldo1}} mV
BIST ldo2: {{ldo2}} mV
BIST ldo3: {{ldo3}} mV
BIST ldo4: {{ldo4}} mV
BIST ldo5: {{ldo5}} mV
BIST ldo6: {{ldo6}} mV
BIST ldo7: {{ldo7}} mV
BIST ldo8: {{ldo8}} mV
BIST ldo9: {{ldo9}} mV
BIST ldo11: {{ldo11}} mV
BIST ldo12: {{ldo12}} mV
BIST ldo13: {{ldo13}} mV
BIST ldo14: {{ldo14}} mV
BIST ldo15: {{ldo15}} mV
BIST ldo16: {{ldo16}} mV
BIST ldo17: {{ldo17}} mV
BIST vrtc: {{vrtc}} mV
BIST chg_hr: {{chg_hr}} mV
BIST chg_hr_off: {{chg_hr_off}} mV
BIST ildo1: {{ildo1}} mA
BIST ildo2: {{ildo2}} mA
BIST ildo3: {{ildo3}} mA
BIST ildo4: {{ildo4}} mA
BIST ildo5: {{ildo5}} mA
BIST ildo6: {{ildo6}} mA
BIST ildo7: {{ildo7}} mA
BIST ildo8: {{ildo8}} mA
BIST ildo9: {{ildo9}} mA
BIST ildo13: {{ildo13}} mA
BIST ildo16: {{ildo16}} mA
BIST ildo17: {{ildo17}} mA
BIST irtc: {{irtc}} mA
BIST iboost: {{iboost}} mA
BIST appmux: {{appmux}} mV
BIST appmux_in1: {{appmux_in1}} mV
BIST appmux_in2: {{appmux_in2}} mV
BIST appmux_in3: {{appmux_in3}} mV
BIST appmux_in4: {{appmux_in4}} mV
BIST appmux_in5: {{appmux_in5}} mV
BIST appmux_in6: {{appmux_in6}} mV
BIST appmux_in7: {{appmux_in7}} mV
BIST appmux_sw2: {{appmux_sw2}} mV
BIST appmux_sw3: {{appmux_sw3}} mV
BIST appmux_sw4: {{appmux_sw4}} mV
BIST appmux_sw6: {{appmux_sw6}} mV
BIST appmux_sw8: {{appmux_sw8}} mV
BIST appmux_sw11: {{appmux_sw11}} mV
BIST appmux_aux_sw_out: {{appmux_aux_sw_out}} mV
BIST appmux_vbuck0: {{appmux_vbuck0}} mV
BIST appmux_vbuck1: {{appmux_vbuck1}} mV
BIST appmux_vbuck4: {{appmux_vbuck4}} mV
BIST appmux_vbuck5: {{appmux_vbuck5}} mV
BIST appmux_vbuck6: {{appmux_vbuck6}} mV
BIST appmux_vbuck7: {{appmux_vbuck7}} mV
BIST appmux_vbuck9: {{appmux_vbuck9}} mV
BIST appmux_vbuck10: {{appmux_vbuck10}} mV
BIST appmux_vldo1: {{appmux_vldo1}} mV
BIST appmux_vldo2: {{appmux_vldo2}} mV
BIST appmux_vldo3: {{appmux_vldo3}} mV
BIST appmux_vldo4: {{appmux_vldo4}} mV
BIST appmux_vldo5: {{appmux_vldo5}} mV
BIST appmux_vldo6: {{appmux_vldo6}} mV
BIST appmux_vldo7: {{appmux_vldo7}} mV
BIST appmux_vldo8: {{appmux_vldo8}} mV
BIST appmux_vldo9: {{appmux_vldo9}} mV
BIST appmux_vldo11: {{appmux_vldo11}} mV
BIST appmux_vldo12: {{appmux_vldo12}} mV
BIST appmux_vldo13: {{appmux_vldo13}} mV
BIST appmux_vldo14: {{appmux_vldo14}} mV
BIST appmux_vldo15: {{appmux_vldo15}} mV
BIST appmux_vldo16: {{appmux_vldo16}} mV
BIST appmux_vldo17: {{appmux_vldo17}} mV
BIST appmux_sw2a_out: {{appmux_sw2a_out}} mV
BIST appmux_sw2b_out: {{appmux_sw2b_out}} mV
BIST appmux_sw2c_out: {{appmux_sw2c_out}} mV
BIST appmux_sw3a_out: {{appmux_sw3a_out}} mV
BIST appmux_sw3b_out: {{appmux_sw3b_out}} mV
BIST appmux_sw3c_out: {{appmux_sw3c_out}} mV
BIST appmux_sw3d_out: {{appmux_sw3d_out}} mV
BIST appmux_sw3e_out: {{appmux_sw3e_out}} mV
BIST appmux_sw4_out: {{appmux_sw4_out}} mV
BIST appmux_sw6_out: {{appmux_sw6_out}} mV
BIST appmux_sw8a_out: {{appmux_sw8a_out}} mV
BIST appmux_sw8b_out: {{appmux_sw8b_out}} mV
BIST appmux_sw11a_out: {{appmux_sw11a_out}} mV
BIST appmux_sw11b_out: {{appmux_sw11b_out}} mV
BIST appmux_sw11c_out: {{appmux_sw11c_out}} mV
BIST appmux_sw18_out: {{appmux_sw18_out}} mV
BIST appmux_sw19_out: {{appmux_sw19_out}} mV
BIST appmux_sw20_out: {{appmux_sw20_out}} mV
BIST appmux_sw21_out: {{appmux_sw21_out}} mV
BIST appmux_pmux_out: {{appmux_pmux_out}} mV
BIST appmux_gpio1: {{appmux_gpio1}} mV
BIST appmux_gpio2: {{appmux_gpio2}} mV
BIST appmux_gpio3: {{appmux_gpio3}} mV
BIST appmux_gpio4: {{appmux_gpio4}} mV
BIST appmux_gpio5: {{appmux_gpio5}} mV
BIST appmux_gpio6: {{appmux_gpio6}} mV
BIST appmux_gpio7: {{appmux_gpio7}} mV
BIST appmux_gpio8: {{appmux_gpio8}} mV
BIST appmux_gpio9: {{appmux_gpio9}} mV
BIST appmux_gpio10: {{appmux_gpio10}} mV
BIST appmux_gpio11: {{appmux_gpio11}} mV
BIST appmux_gpio12: {{appmux_gpio12}} mV
BIST appmux_gpio13: {{appmux_gpio13}} mV
BIST appmux_gpio14: {{appmux_gpio14}} mV
BIST appmux_gpio15: {{appmux_gpio15}} mV
BIST appmux_gpio16: {{appmux_gpio16}} mV
BIST appmux_gpio17: {{appmux_gpio17}} mV
BIST appmux_gpio18: {{appmux_gpio18}} mV
BIST appmux_gpio19: {{appmux_gpio19}} mV
BIST appmux_gpio20: {{appmux_gpio20}} mV
BIST appmux_gpio21: {{appmux_gpio21}} mV
BIST appmux_gpio22: {{appmux_gpio22}} mV
BIST appmux_gpio23: {{appmux_gpio23}} mV
BIST appmux_gpio24: {{appmux_gpio24}} mV
BIST appmux_gpio25: {{appmux_gpio25}} mV
BIST appmux_gpio26: {{appmux_gpio26}} mV
BIST appmux_gpio27: {{appmux_gpio27}} mV
BIST appmux_gpio28: {{appmux_gpio28}} mV
BIST appmux_gpio29: {{appmux_gpio29}} mV
BIST appmux_gpio30: {{appmux_gpio30}} mV
BIST appmux_gpio31: {{appmux_gpio31}} mV
BIST appmux_gpio32: {{appmux_gpio32}} mV
BIST appmux_gpio33: {{appmux_gpio33}} mV
BIST appmux_gpio34: {{appmux_gpio34}} mV
BIST appmux_gpio35: {{appmux_gpio35}} mV
BIST appmux_gpio36: {{appmux_gpio36}} mV
BIST appmux_gpio37: {{appmux_gpio37}} mV
BIST appmux_gpio38: {{appmux_gpio38}} mV
BIST appmux_gpio39: {{appmux_gpio39}} mV
BIST appmux_gpio40: {{appmux_gpio40}} mV
BIST appmux_gpio41: {{appmux_gpio41}} mV
BIST appmux_gpio42: {{appmux_gpio42}} mV
BIST appmux_gpio43: {{appmux_gpio43}} mV
BIST appmux_gpio44: {{appmux_gpio44}} mV
BIST appmux_gpio45: {{appmux_gpio45}} mV
BIST appmux_gpio46: {{appmux_gpio46}} mV
BIST appmux_gpio47: {{appmux_gpio47}} mV
BIST appmux_gpio48: {{appmux_gpio48}} mV
```

pmuadc --read appmux_gpio31 --avg 25
--------
- Command name: `pmuadc --read appmux_gpio31 --avg 25`
- Command to send: `pmuadc --read appmux_gpio31 --avg 25`
```
PMU ADC test
ADC Channel appmux_gpio31: {{appmux_gpio31}} mV
```

pmuadc --read appmux_gpio37 --avg 25
--------
- Command name: `pmuadc --read appmux_gpio37 --avg 25`
- Command to send: `pmuadc --read appmux_gpio37 --avg 25`
```
PMU ADC test
ADC Channel appmux_gpio37: {{appmux_gpio37}} mV
```


Future commands to be parsed
----------------------------
