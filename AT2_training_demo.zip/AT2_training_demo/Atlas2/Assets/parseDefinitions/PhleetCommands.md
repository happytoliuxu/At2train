 Phleet parsing definition file
===========================

Version Info
------------
07/22/2020 ver 0.1

[TOC]

Commands that can be parsed
===========================

factory-phleet-test -timeout=10
--------
```
TExxST_PASSED
```

factory-phleet-test -timeout=720
--------
```
TEST_PASSED
```

factory-phleet-bbq-720
--------
```
TEST_PASSED
```

factory-phleet-test -acc0-apsc-state=6 -soc-state=SOC-PERF-VMAX-STATE -dcs-state=DCS-PERF-VMAX-STATE -timeout=720
--------
```
TEST_PASSED
```

factory-phleet-test -rnd-awake-hot=1 -timeout=720
--------
```
TEST_PASSED
```

Future commands to be parsed
----------------------------
