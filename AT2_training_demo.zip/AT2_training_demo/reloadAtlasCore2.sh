#!/bin/sh
echo '--------------kill atlscore2-----------------'
userName=$(whoami)
echo "user name:$userName"
check_results=`ps -axu $userName|grep AtlasCore2`
#echo "ps commands results:\n$check_results"
IFS='
'
array=($check_results)
atlascore2_PID='0'
for i in "${!array[@]}"; do
    lineStr=${array[i]}
    #echo "$i=>$lineStr"
    if [[ $lineStr =~ '/AppleInternal/usr/local/bin/AtlasCore2' ]]; then
        IFS='  '
        array2=($lineStr)
        atlascore2_PID=${array2[1]}
        break
    fi
done

echo "atlascore2 PID:$atlascore2_PID"

if [[ $atlascore2_PID != '0' ]]; then
    echo "will kill atlascore2..."
    if [[ $(kill $atlascore2_PID) -eq 0 ]]; then
        echo "kill successful"
    else
        echo "ERROR:fial to kill atlascore2"
    fi
else
    echo "ERROR:can't find correct atlascore2 PID!"
fi

echo '--------------------done---------------------'